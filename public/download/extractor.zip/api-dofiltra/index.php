<?php
/*
   Plugin Name: Extractor
   Plugin URI: https://kwork.ru/user/tpscrt
   description: 
   Version: 1.0.10
   Author: noSocial
   Author URI: https://kwork.ru/user/tpscrt
*/

//Настройки


ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(E_ALL);


include("api.php");
function wpschool_api_add_admin_menu( ) {
    add_menu_page( 'Extractor', 'Extractor', 'manage_options', 'extractor-dofiltra', 'settings_extractor_dofiltra_page' );
}

function settings_notification_subs_init( ) {
	   register_setting( 'SettingsAPIDofiltra', 'settings_dofiltra_api' );
    add_settings_section(
        'settings_dofiltra_section',
        __( 'Настройки API', 'wordpress' ),
        'settings_dofiltra_section_section_callback',
        'SettingsAPIDofiltra'
    );

    add_settings_field(
        'api_token',
        __( 'API токен	', 'wordpress' ),
        'settings_dofiltra_section_render',
        'SettingsAPIDofiltra',
        'settings_dofiltra_section'
    );
	
}


function settings_dofiltra_section_section_callback( ) {}


function settings_dofiltra_section_render( ) {
    $options = get_option( 'settings_dofiltra_api' );
	$value = '';
	if($options){
		$value = $options['api_token'];
	}
    ?>
    <input type='text' name='settings_dofiltra_api[api_token]' value='<?=$value?>'>
    <?php
	if($options){
$APIdofiltra = new APIdofiltra($value);
if($response = $APIdofiltra->getBalance()){
	
		?>
		<p>Баланс токена: <strong><?=$response?></strong> монет</p>
		<?php
}
	}
    
	
}


function ExtractTranslitURL($str) 
{
    $tr = array(
        "А"=>"a","Б"=>"b","В"=>"v","Г"=>"g",
        "Д"=>"d","Е"=>"e","Ё"=>"yo","Ж"=>"zh","З"=>"z","И"=>"i",
        "Й"=>"j","К"=>"k","Л"=>"l","М"=>"m","Н"=>"n",
        "О"=>"o","П"=>"p","Р"=>"r","С"=>"s","Т"=>"t",
        "У"=>"u","Ф"=>"f","Х"=>"x","Ц"=>"c","Ч"=>"ch",
        "Ш"=>"sh","Щ"=>"shh","Ъ"=>"j","Ы"=>"y","Ь"=>"",
        "Э"=>"e","Ю"=>"yu","Я"=>"ya","а"=>"a","б"=>"b",
        "в"=>"v","г"=>"g","д"=>"d","е"=>"e","ё"=>"yo","ж"=>"zh",
        "з"=>"z","и"=>"i","й"=>"j","к"=>"k","л"=>"l",
        "м"=>"m","н"=>"n","о"=>"o","п"=>"p","р"=>"r",
        "с"=>"s","т"=>"t","у"=>"u","ф"=>"f","х"=>"x",
        "ц"=>"c","ч"=>"ch","ш"=>"sh","щ"=>"shh","ъ"=>"j",
        "ы"=>"y","ь"=>"","э"=>"e","ю"=>"yu","я"=>"ya", 
        " "=> "-", "."=> "", "І"=> "i",
        "і"=> "i", "Ң"=> "n", "ң"=> "n", 
		"Ү"=> "u", "ү"=> "u", "Қ"=> "q", 
		"қ"=> "q", "Ұ"=> "u",
        "ұ"=> "u", "Ғ"=> "g", "ғ"=> "g", 
		"Ө"=> "o", "ө"=> "o", "Ә"=> "a", 
		"ә"=> "a"			 				
    );
	
    $urlstr = str_replace('–'," ",$str);
    $urlstr = str_replace('-'," ",$urlstr); 
    $urlstr = str_replace('—'," ",$urlstr);

    $urlstr=preg_replace('/\s+/',' ',$urlstr);
     if (preg_match('/[^A-Za-z0-9_\-]/', $urlstr)) {
        $urlstr = strtr($urlstr,$tr);
        $urlstr = preg_replace('/[^A-Za-z0-9_\-]/', '', $urlstr);
        $urlstr = strtolower($urlstr);
        return $urlstr;
    } else {
        return strtolower($str);
    }
}








	
function extractor_dofiltra_upload_image($urli) {
	$ats = get_posts(array(
		'post_type'		=>	'attachment',
		'post_mime_type' => 'image',
		'post_status'    => null,
		'numberposts' => 1,
		'meta_query' => array(
			array(
				'key' => 'extractor_dofiltra_url',
				'value' => $urli,
				'compare' => '=',
			)
		),
		'suppress_filters' => true,
	));
	if (isset($ats[0])) {
		$attach_id = $ats[0]->ID;
	} else {
		$filename = wp_upload_dir()['path'].'/'.basename($urli);
		copy($urli, $filename);

		$parent_post_id = 0;

		$filetype = wp_check_filetype( basename( $filename ), null );

		$wp_upload_dir = wp_upload_dir();

		$attachment = array(
			'guid'           => $wp_upload_dir['url'] . '/' . basename( $filename ), 
			'post_mime_type' => $filetype['type'],
			'post_title'     => preg_replace( '/\.[^.]+$/', '', basename( $filename ) ),
			'post_content'   => '',
			'post_status'    => 'inherit'
		);

		$attach_id = wp_insert_attachment( $attachment, $filename, $parent_post_id );
		require_once( ABSPATH . 'wp-admin/includes/image.php' );
		$attach_data = wp_generate_attachment_metadata( $attach_id, $filename );
		wp_update_attachment_metadata( $attach_id, $attach_data );
		update_post_meta( $attach_id, 'extractor_dofiltra_url', $urli );
	}
	return $attach_id;
}


function getExcractPost($post_id,$id){

 $options = get_option( 'settings_dofiltra_api' );
$APIdofiltra = new APIdofiltra($options['api_token']);
	
	
$response = $APIdofiltra->getExtract($id);
if($response["item"]["union"]) {
	

//foreach($response["item"]["union"] as $result){
	$update_post = array();
$update_post['ID'] = $post_id;
$update_post['post_content'] = $response["item"]["union"]["content"];
$update_post['post_title'] = $response["item"]["union"]["title"];
if (get_post_meta( $post_id, 'extractor_dofiltra_draft', 1) == 'yes') {
	$update_post['post_status'] ='draft';
} else {
	$update_post['post_status'] ='future';
}
$update_post['post_name'] = ExtractTranslitURL($response["item"]["union"]["title"]);

wp_update_post( wp_slash($update_post) );
//}

update_post_meta( $post_id, 'completed_dofiltra', 1);
update_post_meta( $post_id, '_dofiltra_urlsOrKeys', $response["item"]["urlsOrKeys"]);

if (mb_strlen($response["item"]["union"]["content"]) < 3000) {
	wp_trash_post($post_id);
}


if (strpos($response["item"]["union"]["content"], '<img ') !== false) {
	$pmt = array();
	preg_match_all('<img [^<>]*(?=src[\s]*=)src[\s]*=[\s]*[(\'|")][\s]*([^(\'|")]*)[\s]*[(\'|")][^<>]*>', $response["item"]["union"]["content"], $pmt); //"
	if (isset($pmt[1][0])) {
		try {
			set_post_thumbnail($post_id, extractor_dofiltra_upload_image($pmt[1][0]));
		} catch (Exception $e) {}
	}
}
}

}


function showStories(){
?>


   <thead style="background: #FFF">
    <tr>
     <td>Задания</td>
     <td>Ключи/ссылки</td> 
     <td>Статус</td> 
    </tr> 
   </thead>

				<?php
				$size_page = 10;
 $options = get_option( 'settings_dofiltra_api' );
//$APIdofiltra = new APIdofiltra($options['api_token']);
$args = array(
   'meta_query' => array(
       array(
           'key' => 'id_dofiltra',
           'compare' => 'EXISTS',
       )
   ),
   	'post_status' => array( 'publish', 'private', 'pending', 'draft', 'future', 'trash' ),
   	'post_type' => 'any',
);
$q = new WP_Query($args);
$count_posts = $q->found_posts;


if(isset($_GET['page_query'])){
	$current_page = $_GET['page_query'];
	$total_pages = ceil($count_posts / $size_page);
	$offset = ($current_page-1) * $size_page;
		$args = array(
   'meta_query' => array(
       array(
           'key' => 'id_dofiltra',
           'compare' => 'EXISTS',
       )
   ),
	   'posts_per_page' => $size_page,
	   'offset' => $offset,
	   
   	'post_status' => array( 'publish', 'private', 'pending', 'draft', 'future', 'trash' ),
   	'post_type' => 'any',
);
}else{
	$current_page = 1;
	$total_pages = ceil($count_posts / $size_page);
		$args = array(
   'meta_query' => array(
       array(
           'key' => 'id_dofiltra',
           'compare' => 'EXISTS',
       )
   ),
	   'posts_per_page' => $size_page,
	   'offset' => 0,
	   
   	'post_status' => array( 'publish', 'private', 'pending', 'draft', 'future', 'trash' ),
   	'post_type' => 'any',
);
}

$q = new WP_Query($args);
if( $q->have_posts() ) :
 
	while( $q->have_posts() ) : $q->the_post();
	$id_dofiltra = get_post_meta( get_the_ID(), 'id_dofiltra', true );
//$response = $APIdofiltra->getExtract( $id_dofiltra);
$completed_dofiltra = get_post_meta( get_the_ID(), 'completed_dofiltra', true );

?>


			<tr class="importer-item">
				<td class="import-system">
					<span class="importer-title"><?=get_the_title()?></span>
					<span class="importer-action"><a href="<?=get_permalink()?>" class="install-now">Посмотреть на сайте</a> | <a href="<?=get_admin_url()?>post.php?post=<?=get_the_ID()?>&action=edit">Редактировать</a> | <a href="https://ai.dofiltra.com/extractor/result/<?=$id_dofiltra?>">Посмотреть задание</a></span>
				</td>
				<td class="desc">
					<span class="importer-desc">
					<?php
					$s = get_post_meta(get_the_ID(), '_extractor_dofiltra_keys_array', 1);
					if (!empty($s)) {
						foreach($s as $result){
							echo $result.'<br>';
						}
					}
					?></span>
				</td>
					<td class="desc">
					<span class="importer-desc">
					<?php
					if($completed_dofiltra){
						if (get_post(get_the_ID())->post_status == 'trash') {
							echo 'Выполнен и пост удалён';
						} else {
							echo 'Выполнен';
						}
					}else{
						echo 'В работе<br>';
					}
					?></span>
				</td>
			</tr>
		
<?php

	endwhile;
endif;
 
wp_reset_postdata();
$url_pagination = get_admin_url() . 'options-general.php?page=extractor-dofiltra&tab=stories&page_query=';

?>
   <tfoot align="right" style="background: #f6f7f7;">
    <tr>
     <td></td>
	      <td></td> 
<td>


<div class="tablenav-pages">
  <span class="pagination-links">
  
  <a class="next-page button <?php if($current_page <= 1){ echo 'disabled'; } ?>" href="<?php if($current_page <= 1){ echo '#'; } else { echo $url_pagination.($current_page - 1); } ?>"><span class="screen-reader-text">Следующая страница</span><span aria-hidden="true">‹</span></a>
  <span class="paging-input"><label for="current-page-selector" class="screen-reader-text">Текущая страница</label>
  <input class="current-page" id="current-page-selector" type="text" name="paged" value="<?=$current_page?>/<?=$total_pages?>" size="4" disabled aria-describedby="table-paging">
  </span>
  <a class="next-page button <?php if($current_page >= $total_pages){ echo 'disabled'; } ?>" href="<?php if($current_page >= $total_pages){ echo '#'; } else { echo $url_pagination.($current_page + 1); } ?>"><span class="screen-reader-text">Предыдущая страница</span><span aria-hidden="true">›</span></a>
  </span>
</div>










</td> 

    </tr> 
   </tfoot>


<?php
}

add_action( 'admin_notices', 'extractor_dofiltra_notice_balance_required' );
function extractor_dofiltra_notice_balance_required() {
	if (get_option('extractor_dofiltra_balance_required', 'no') == 'yes') {
	?>
	<div class="notice notice-error">
		<p>Пополните баланс AI Rewriter API</p>
	</div>
	<?php
	}
}


function addExtractPost($keyLink = null, $pst = null, $clock = null){
$options = get_option( 'settings_dofiltra_api' );
$APIdofiltra = new APIdofiltra($options['api_token']);
if ($keyLink === null) {
	$keyLink = explode(PHP_EOL, $_POST['keyLink']);
}
$klts = $keyLink;
if ($pst === null) {
	$pst = $_POST;
}

$array = array();
$i = 0;
foreach($keyLink as $line) {
	if(strlen($line)>3){
   	
        	
        	$array[$i][] = $line;
    	
    	}else{
        	$i++;
    	}
}
if ($clock === null) {$clock=1;}

$contentOpts = ['limitContent'=>(int)$pst['limit_chars_count'],'coefShuffleBlocks'=>(int)$pst['shuffle_blocks']];
$duplicateOpts = ['coefRemoveHeading'=>(int)$pst['remove_similar_headings'],'coefRemoveContent'=>(int)$pst['remove_similar_content_bloks']];

$google_parser = isset($pst['parser_google']) ? $pst['parser_google'] : 'no';
$yandex_parser = isset($pst['parser_yandex']) ? $pst['parser_yandex'] : 'no';

if ($google_parser == 'yes') {
	$googleParserOpts = array('enable' => true, 'device' => $pst['parser_google_device'], 'domain' => $pst['parser_google_domain'], 'country' => $pst['parser_google_country'], 'loc' => $pst['parser_google_location'], 'lr' => $pst['parser_google_language']);
} else {
	$googleParserOpts = array('enable' => false);
}

if ($yandex_parser == 'yes') {
	$yandexParserOpts = array('enable' => true);
} else {
	$yandexParserOpts = array('enable' => false);
}
$title = 'draft';
if($pst['postTitle']){
	$title = $pst['postTitle'];
}

$response = $APIdofiltra->addExtract($array,$contentOpts,$duplicateOpts,$googleParserOpts,$yandexParserOpts);
if($response["error"]){
if($response["error"]=='BALANCE_REQUIRED'){
	update_option('extractor_dofiltra_balance_required', 'yes');
	exit;
} else {
	update_option('extractor_dofiltra_balance_required', 'no');
}
} else {
	update_option('extractor_dofiltra_balance_required', 'no');
}



foreach($response["result"] as $idx => $result) {
	$rclock = $clock*$pst['interval_publish'];
	$current_timestamp = time();
	$current_timestamp =  strtotime('+240 minutes', $current_timestamp);
	$current_timestamp =  strtotime("+$rclock minutes", $current_timestamp);
	
	$postdate = date('Y-m-d H:i:s', $current_timestamp);
	
	$id = $result["_id"];
$post_data = array(
	'post_title'    => sanitize_text_field($title),
	'post_content'  => '',
	'post_date'     => $postdate,
	'post_status'   => 'future',
	'post_author'   => 1,
	'post_category' => array($pst['categoryPost'])
);

	$post_id = wp_insert_post( $post_data );
	if ((int)$pst['interval_publish'] == 0) {
		update_post_meta( $post_id, 'extractor_dofiltra_draft', 'yes');
	}
	update_post_meta( $post_id, 'id_dofiltra', $id);
	//update_post_meta( $post_id, '_group_key_dofiltra', $pst['keyLink']);
	if (isset($array[$idx])) {
		update_post_meta( $post_id, '_extractor_dofiltra_keys_array', $array[$idx]);
	}
	update_post_meta( $post_id, '_history_extractor', 'https://ai.dofiltra.com/extractor/result/'.$id);
	$clock++;
}
}


function addExtractPostOld($keyLink = null, $pst = null, $clock = null){
$options = get_option( 'settings_dofiltra_api' );
$APIdofiltra = new APIdofiltra($options['api_token']);
if ($keyLink === null) {
	$keyLink = explode(PHP_EOL, $_POST['keyLink']);
}
$klts = $keyLink;
if ($pst === null) {
	$pst = $_POST;
}

$array = array();
$i = 0;
$qu = 0;
$kls = array();
foreach($keyLink as $line) {

	if ($i >= 50) {
		if ($qu == 0) {$qu = 1;}
			$kls[] = $line;
			if(strlen($line)<=3){
				$qu++;
			}
	} else {
	if(strlen($line)>3){
   	
        	
        	$array[$i][] = $line;
    	
    	}else{
        	$i++;
    	}
    }
}
if ($clock === null) {$clock=1;}
foreach($array as $keyLink) {
//print_r($keyLink);

$contentOpts = ['limitContent'=>$pst['limit_chars_count'],'coefShuffleBlocks'=>$pst['shuffle_blocks']];
$duplicateOpts = ['coefRemoveHeading'=>$pst['remove_similar_headings'],'coefRemoveContent'=>$pst['remove_similar_content_bloks']];

$google_parser = isset($pst['parser_google']) ? $pst['parser_google'] : 'no';
$yandex_parser = isset($pst['parser_yandex']) ? $pst['parser_yandex'] : 'no';

if ($google_parser == 'yes') {
	$googleParserOpts = array('enable' => true, 'device' => $pst['parser_google_device'], 'domain' => $pst['parser_google_domain'], 'country' => $pst['parser_google_country'], 'loc' => $pst['parser_google_location'], 'lr' => $pst['parser_google_language']);
} else {
	$googleParserOpts = array('enable' => false);
}

if ($yandex_parser == 'yes') {
	$yandexParserOpts = array('enable' => true);
} else {
	$yandexParserOpts = array('enable' => false);
}

$response = $APIdofiltra->addExtractOld($keyLink,$contentOpts,$duplicateOpts,$googleParserOpts,$yandexParserOpts);
if($response["error"]){
if($response["error"]=='BALANCE_REQUIRED'){
	update_option('extractor_dofiltra_balance_required', 'yes');
	exit;
} else {
	update_option('extractor_dofiltra_balance_required', 'no');
}
} else {
	update_option('extractor_dofiltra_balance_required', 'no');
}
$title = 'draft';
if($pst['postTitle']){
	$title = $pst['postTitle'];
}
$rclock = $clock*$pst['interval_publish'];
$current_timestamp = time();
$current_timestamp =  strtotime('+240 minutes', $current_timestamp);
$current_timestamp =  strtotime("+$rclock minutes", $current_timestamp);

$postdate = date('Y-m-d H:i:s', $current_timestamp);
foreach($response["result"] as $result) {
	
	$id = $result["_id"];
$post_data = array(
	'post_title'    => sanitize_text_field($title),
	'post_content'  => '',
	'post_date'     => $postdate,
	'post_status'   => 'future',
	'post_author'   => 1,
	'post_category' => array($pst['categoryPost'])
);

$post_id = wp_insert_post( $post_data );
if ((int)$pst['interval_publish'] == 0) {
	update_post_meta( $post_id, 'extractor_dofiltra_draft', 'yes');
}
update_post_meta( $post_id, 'id_dofiltra', $id);
update_post_meta( $post_id, '_group_key_dofiltra', $pst['keyLink']);
update_post_meta( $post_id, '_extractor_dofiltra_keys_array', $keyLink);
update_post_meta( $post_id, '_history_extractor', 'https://ai.dofiltra.com/extractor/result/'.$id);

}
//sleep(2);
				//	getExcractPost($post_id, $id);
					$clock++;
					$k++;
}
if (!empty($kls) && $clock > 1) {
	update_option('extractor_dofiltra_task_queue', $qu);
	wp_schedule_single_event(time() + 60, 'extractor_dofiltra_add_post_queue', array($kls, $pst, $clock));
} else {
	update_option('extractor_dofiltra_task_queue', 0);
}
}

add_action('extractor_dofiltra_add_post_queue', 'addExtractPostOld', 1, 3);


function settings_extractor_dofiltra_page( ) {
	global $wpdb;
	$h = get_option('extractor_dofiltra_task_queue', 0);
    ?>


        <h2>Извлекатор</h2>
		<div class="tab">
		<?php
if(isset($_GET['tab'])){
		?>
  <a class="tablinks <?php if(($_GET['tab']=='new') OR (!isset($_GET['tab']))){echo 'active';}	?>" href="options-general.php?page=extractor-dofiltra&tab=new" id="subscribesTab">Добавить новый пост</a>
  <a class="tablinks <?php if($_GET['tab']=='stories'){echo 'active';}	?>" href="options-general.php?page=extractor-dofiltra&tab=stories" >История<?php if ($h > 0) { ?> (в очереди: <?php echo $h; ?>)<?php } ?></a>
  <a class="tablinks <?php if($_GET['tab']=='settings'){echo 'active';}	?>" href="options-general.php?page=extractor-dofiltra&tab=settings" >Статистика/настройки</a>
  <?php
}else{
	?>
  <a class="tablinks active" href="options-general.php?page=extractor-dofiltra&tab=new" id="subscribesTab">Добавить новый пост</a>
  <a class="tablinks" href="options-general.php?page=extractor-dofiltra&tab=stories" >История<?php if ($h > 0) { ?> (в очереди: <?php echo $h; ?>)<?php } ?></a>
  <a class="tablinks" href="options-general.php?page=extractor-dofiltra&tab=settings" >Статистика/настройки</a>
  <?php

}
		?>
</div>


	        <?php
if(($_GET['tab']=='new') OR (!isset($_GET['tab']))){
	if(isset($_POST['categoryPost'])){
		addExtractPost();
	}
	?>
	<form action='options-general.php?page=extractor-dofiltra&tab=new' method='post'>
<div class="tabcontent">

<table class="form-table" role="presentation">
<tbody>
		
<tr style="display:none">
<th scope="row">Название статьи:</th>
<td>
<input type="text" name="postTitle" value="">

		</td>
		
		</tr>
<tr>
<th scope="row">Категория:</th>
<td>
	<select class="js-products-multiple" name="categoryPost">
			<?php
		$categories = get_categories( [
	'taxonomy'     => 'category',
	'type'         => 'post',
	'child_of'     => 0,
	'parent'       => '',
	'orderby'      => 'name',
	'order'        => 'ASC',
	'hide_empty'   => 0,
	'hierarchical' => 1,
	'exclude'      => '',
	'include'      => '',
	'number'       => 0,
	'pad_counts'   => false,
] );



if( $categories ){
	foreach( $categories as $cat ){

		?>	
	<option value="<?=$cat->term_id;?>"><?=$cat->name;?></option>		
<?php	


		
				}
}
			
			?>
	</select>

		</td>
		</tr>
		
		
<tr>
<th scope="row">Ссылки/ключи:</th>
<td>
<textarea rows="10" cols="145" id="keyLink" name="keyLink"></textarea>

		</td>
		
		</tr>
		
				
<tr>
<th scope="row"></th>
<td>

<input type="button" class="button button-primary" id="ungroup" value="Разделить группы">
<p class="ungroup" id="ungroup-description">*Построчное разнесение ключей по разделителям: (,)(tab)</p>
		</td>
		
		</tr>
		
			<tr>
<th scope="row">Интервал публикаций, минут<br />
(0=размещать в черновиках):</th>
<td>
<input type="number" name="interval_publish" value="30">
		</td>
		</tr>

		
		<tr>
<th scope="row">Максимальное количество символов:</th>
<td>
<input type="number" name="limit_chars_count" value="50000">
		</td>
		</tr>
		
			<tr>
<th scope="row">Сила перемешивания блоков<br />(0..100, 0 = не перемешивать):</th>
<td>
<input type="number" name="shuffle_blocks" value="0" max="100">
		</td>
		</tr>
		
				<tr>
<th scope="row">Степень похожести удаляемых заголовков (0..100):</th>
<td>
<input type="number" name="remove_similar_headings" value="80" max="100">
		</td>
		</tr>
		
		<tr>
<th scope="row">Степень похожести удаляемых блоков (0..100):</th>
<td>
<input type="number" name="remove_similar_content_bloks" value="70" max="100">
		</td>
		</tr>
		<tr>
<th scope="row">Парсер Google:</th>
<td>
<input type="checkbox" name="parser_google" value="yes" onclick="if (this.checked) {document.querySelectorAll('.parser_google_data').forEach(function(el) {el.style.display = '';});} else {document.querySelectorAll('.parser_google_data').forEach(function(el) {el.style.display = 'none';});}">
		</td>
		</tr>
		
						<tr class="parser_google_data" style="display: none;">
	<th scope="row">Парсер Google, устройство:</th>
	<td>
	<select name="parser_google_device"><option value="desktop">ПК</option><option value="tablet">Планшет</option><option value="mobile" selected="selected">Смартфон</option></select>
			</td>
			</tr>
			<tr class="parser_google_data" style="display: none;">
	<th scope="row">Парсер Google, доменная зона:</th>
	<td>
	<select name="parser_google_domain"><option value="128">ac</option><option value="9">ad</option><option value="126">ae</option><option value="4">al</option><option value="12">am</option><option value="6">as</option><option value="2">at</option><option value="3">az</option><option value="23">ba</option><option value="19">be</option><option value="28">bf</option><option value="21">bg</option><option value="29">bi</option><option value="20">bj</option><option value="14">bs</option><option value="18">by</option><option value="77">ca</option><option value="78">cat</option><option value="86">cc</option><option value="57">cd</option><option value="182">cf</option><option value="141">cg</option><option value="187">ch</option><option value="89">ci</option><option value="186">cl</option><option value="76">cm</option><option value="85">cn</option><option value="8">co.ao</option><option value="24">co.bw</option><option value="131">co.ck</option><option value="88">co.cr</option><option value="67">co.id</option><option value="65">co.il</option><option value="66">co.in</option><option value="195">co.jp</option><option value="80">co.ke</option><option value="142">co.kr</option><option value="94">co.ls</option><option value="108">co.ma</option><option value="111">co.mz</option><option value="124">co.nz</option><option value="163">co.th</option><option value="164">co.tz</option><option value="172">co.ug</option><option value="31">co.uk</option><option value="173">co.uz</option><option value="33">co.ve</option><option value="35">co.vi</option><option value="193">co.za</option><option value="63">co.zm</option><option value="64">co.zw</option><option value="37">com</option><option value="13">com.af</option><option value="10">com.ag</option><option value="7">com.ai</option><option value="11">com.ar</option><option value="1">com.au</option><option value="15">com.bd</option><option value="16">com.bh</option><option value="27">com.bn</option><option value="22">com.bo</option><option value="25">com.br</option><option value="17">com.bz</option><option value="87">com.co</option><option value="90">com.cu</option><option value="81">com.cy</option><option value="61">com.do</option><option value="190">com.ec</option><option value="62">com.eg</option><option value="192">com.et</option><option value="176">com.fj</option><option value="43">com.gh</option><option value="49">com.gi</option><option value="45">com.gt</option><option value="51">com.hk</option><option value="194">com.jm</option><option value="75">com.kh</option><option value="91">com.kw</option><option value="95">com.lb</option><option value="153">com.lc</option><option value="96">com.ly</option><option value="115">com.mm</option><option value="107">com.mt</option><option value="109">com.mx</option><option value="104">com.my</option><option value="116">com.na</option><option value="130">com.nf</option><option value="120">com.ng</option><option value="122">com.ni</option><option value="118">com.np</option><option value="127">com.om</option><option value="134">com.pa</option><option value="137">com.pe</option><option value="135">com.pg</option><option value="177">com.ph</option><option value="133">com.pk</option><option value="140">com.pr</option><option value="136">com.py</option><option value="79">com.qa</option><option value="149">com.sa</option><option value="158">com.sb</option><option value="155">com.sg</option><option value="161">com.sl</option><option value="146">com.sv</option><option value="162">com.tj</option><option value="169">com.tn</option><option value="171">com.tr</option><option value="84">com.tw</option><option value="174">com.ua</option><option value="175">com.uy</option><option value="152">com.vc</option><option value="38">com.vn</option><option value="73">cv</option><option value="185">cz</option><option value="47">de</option><option value="59">dj</option><option value="56">dk</option><option value="60">dm</option><option value="5">dz</option><option value="191">ee</option><option value="71">es</option><option value="178">fi</option><option value="110">fm</option><option value="180">fr</option><option value="39">ga</option><option value="55">ge</option><option value="46">gf</option><option value="48">gg</option><option value="53">gl</option><option value="42">gm</option><option value="44">gp</option><option value="54">gr</option><option value="41">gy</option><option value="50">hn</option><option value="181">hr</option><option value="40">ht</option><option value="32">hu</option><option value="179">ie</option><option value="129">im</option><option value="26">io</option><option value="69">iq</option><option value="70">is</option><option value="72">it</option><option value="58">je</option><option value="68">jo</option><option value="82">kg</option><option value="83">ki</option><option value="74">kz</option><option value="92">la</option><option value="98">li</option><option value="189">lk</option><option value="97">lt</option><option value="99">lu</option><option value="93">lv</option><option value="112">md</option><option value="184">me</option><option value="101">mg</option><option value="102">mk</option><option value="105">ml</option><option value="113">mn</option><option value="114">ms</option><option value="100">mu</option><option value="106">mv</option><option value="103">mw</option><option value="119">ne</option><option value="121">nl</option><option value="125">no</option><option value="117">nr</option><option value="123">nu</option><option value="138">pl</option><option value="132">pn</option><option value="52">ps</option><option value="139">pt</option><option value="145">ro</option><option value="154">rs</option><option value="143" selected="selected">ru</option><option value="144">rw</option><option value="150">sc</option><option value="188">se</option><option value="157">si</option><option value="156">sk</option><option value="151">sn</option><option value="159">so</option><option value="148">st</option><option value="183">td</option><option value="165">tg</option><option value="166">tk</option><option value="36">tl</option><option value="170">tm</option><option value="167">to</option><option value="168">tt</option><option value="160">us</option><option value="34">vg</option><option value="30">vu</option><option value="147">ws</option></select>
			</td>
			</tr>
			<tr class="parser_google_data" style="display: none;">
	<th scope="row">Парсер Google, страна:</th>
	<td>
	<select name="parser_google_country"><option value="2004">Afghanistan</option><option value="2008">Albania</option><option value="2010">Antarctica</option><option value="2012">Algeria</option><option value="2016">American Samoa</option><option value="2020">Andorra</option><option value="2024">Angola</option><option value="2028">Antigua and Barbuda</option><option value="2031">Azerbaijan</option><option value="2032">Argentina</option><option value="2036">Australia</option><option value="2040">Austria</option><option value="2044">The Bahamas</option><option value="2048">Bahrain</option><option value="2050">Bangladesh</option><option value="2051">Armenia</option><option value="2052">Barbados</option><option value="2056">Belgium</option><option value="2064">Bhutan</option><option value="2068">Bolivia</option><option value="2070">Bosnia and Herzegovina</option><option value="2072">Botswana</option><option value="2076">Brazil</option><option value="2084">Belize</option><option value="2090">Solomon Islands</option><option value="2096">Brunei</option><option value="2100">Bulgaria</option><option value="2104">Myanmar (Burma)</option><option value="2108">Burundi</option><option value="2112">Belarus</option><option value="2116">Cambodia</option><option value="2120">Cameroon</option><option value="2124">Canada</option><option value="2132">Cape Verde</option><option value="2140">Central African Republic</option><option value="2144">Sri Lanka</option><option value="2148">Chad</option><option value="2152">Chile</option><option value="2156">China</option><option value="2162">Christmas Island</option><option value="2166">Cocos (Keeling) Islands</option><option value="2170">Colombia</option><option value="2174">Comoros</option><option value="2178">Republic of the Congo</option><option value="2180">Democratic Republic of the Congo</option><option value="2184">Cook Islands</option><option value="2188">Costa Rica</option><option value="2191">Croatia</option><option value="2196">Cyprus</option><option value="2203">Czechia</option><option value="2204">Benin</option><option value="2208">Denmark</option><option value="2212">Dominica</option><option value="2214">Dominican Republic</option><option value="2218">Ecuador</option><option value="2222">El Salvador</option><option value="2226">Equatorial Guinea</option><option value="2231">Ethiopia</option><option value="2232">Eritrea</option><option value="2233">Estonia</option><option value="2239">South Georgia and the South Sandwich Islands</option><option value="2242">Fiji</option><option value="2246">Finland</option><option value="2250">France</option><option value="2258">French Polynesia</option><option value="2260">French Southern and Antarctic Lands</option><option value="2262">Djibouti</option><option value="2266">Gabon</option><option value="2268">Georgia</option><option value="2270">The Gambia</option><option value="2276">Germany</option><option value="2288">Ghana</option><option value="2296">Kiribati</option><option value="2300">Greece</option><option value="2308">Grenada</option><option value="2316">Guam</option><option value="2320">Guatemala</option><option value="2324">Guinea</option><option value="2328">Guyana</option><option value="2332">Haiti</option><option value="2334">Heard Island and McDonald Islands</option><option value="2336">Vatican City</option><option value="2340">Honduras</option><option value="2348">Hungary</option><option value="2352">Iceland</option><option value="2356">India</option><option value="2360">Indonesia</option><option value="2368">Iraq</option><option value="2372">Ireland</option><option value="2376">Israel</option><option value="2380">Italy</option><option value="2384">Cote d'Ivoire</option><option value="2388">Jamaica</option><option value="2392">Japan</option><option value="2398">Kazakhstan</option><option value="2400">Jordan</option><option value="2404">Kenya</option><option value="2410">South Korea</option><option value="2414">Kuwait</option><option value="2417">Kyrgyzstan</option><option value="2418">Laos</option><option value="2422">Lebanon</option><option value="2426">Lesotho</option><option value="2428">Latvia</option><option value="2430">Liberia</option><option value="2434">Libya</option><option value="2438">Liechtenstein</option><option value="2440">Lithuania</option><option value="2442">Luxembourg</option><option value="2450">Madagascar</option><option value="2454">Malawi</option><option value="2458">Malaysia</option><option value="2462">Maldives</option><option value="2466">Mali</option><option value="2470">Malta</option><option value="2478">Mauritania</option><option value="2480">Mauritius</option><option value="2484">Mexico</option><option value="2492">Monaco</option><option value="2496">Mongolia</option><option value="2498">Moldova</option><option value="2499">Montenegro</option><option value="2504">Morocco</option><option value="2508">Mozambique</option><option value="2512">Oman</option><option value="2516">Namibia</option><option value="2520">Nauru</option><option value="2524">Nepal</option><option value="2528">Netherlands</option><option value="2531">Curacao</option><option value="2534">Sint Maarten</option><option value="2535">Caribbean Netherlands</option><option value="2540">New Caledonia</option><option value="2548">Vanuatu</option><option value="2554">New Zealand</option><option value="2558">Nicaragua</option><option value="2562">Niger</option><option value="2566">Nigeria</option><option value="2570">Niue</option><option value="2574">Norfolk Island</option><option value="2578">Norway</option><option value="2580">Northern Mariana Islands</option><option value="2581">United States Minor Outlying Islands</option><option value="2583">Federated States of Micronesia</option><option value="2584">Marshall Islands</option><option value="2585">Palau</option><option value="2586">Pakistan</option><option value="2591">Panama</option><option value="2598">Papua New Guinea</option><option value="2600">Paraguay</option><option value="2604">Peru</option><option value="2608">Philippines</option><option value="2612">Pitcairn Islands</option><option value="2616">Poland</option><option value="2620">Portugal</option><option value="2624">Guinea-Bissau</option><option value="2626">Timor-Leste</option><option value="2634">Qatar</option><option value="2642">Romania</option><option value="2643" selected="selected">Russia</option><option value="2646">Rwanda</option><option value="2654">Saint Helena</option><option value="2659">Saint Kitts and Nevis</option><option value="2662">Saint Lucia</option><option value="2666">Saint Pierre and Miquelon</option><option value="2670">Saint Vincent and the Grenadines</option><option value="2674">San Marino</option><option value="2678">Sao Tome and Principe</option><option value="2682">Saudi Arabia</option><option value="2686">Senegal</option><option value="2688">Serbia</option><option value="2690">Seychelles</option><option value="2694">Sierra Leone</option><option value="2702">Singapore</option><option value="2703">Slovakia</option><option value="2704">Vietnam</option><option value="2705">Slovenia</option><option value="2706">Somalia</option><option value="2710">South Africa</option><option value="2716">Zimbabwe</option><option value="2724">Spain</option><option value="2740">Suriname</option><option value="2748">Swaziland</option><option value="2752">Sweden</option><option value="2756">Switzerland</option><option value="2762">Tajikistan</option><option value="2764">Thailand</option><option value="2768">Togo</option><option value="2772">Tokelau</option><option value="2776">Tonga</option><option value="2780">Trinidad and Tobago</option><option value="2784">United Arab Emirates</option><option value="2788">Tunisia</option><option value="2792">Turkey</option><option value="2795">Turkmenistan</option><option value="2798">Tuvalu</option><option value="2800">Uganda</option><option value="2804">Ukraine</option><option value="2807">Macedonia (FYROM)</option><option value="2818">Egypt</option><option value="2826">United Kingdom</option><option value="2831">Guernsey</option><option value="2832">Jersey</option><option value="2834">Tanzania</option><option value="2840">United States</option><option value="2854">Burkina Faso</option><option value="2858">Uruguay</option><option value="2860">Uzbekistan</option><option value="2862">Venezuela</option><option value="2876">Wallis and Futuna</option><option value="2882">Samoa</option><option value="2887">Yemen</option><option value="2894">Zambia</option></select>
			</td>
			</tr>
			<tr class="parser_google_data" style="display: none;">
	<th scope="row">Парсер Google, местоположение:</th>
	<td>
	<select name="parser_google_location"><option value="2004">Afghanistan</option><option value="2008">Albania</option><option value="2010">Antarctica</option><option value="2012">Algeria</option><option value="2016">American Samoa</option><option value="2020">Andorra</option><option value="2024">Angola</option><option value="2028">Antigua and Barbuda</option><option value="2031">Azerbaijan</option><option value="2032">Argentina</option><option value="2036">Australia</option><option value="2040">Austria</option><option value="2044">The Bahamas</option><option value="2048">Bahrain</option><option value="2050">Bangladesh</option><option value="2051">Armenia</option><option value="2052">Barbados</option><option value="2056">Belgium</option><option value="2064">Bhutan</option><option value="2068">Bolivia</option><option value="2070">Bosnia and Herzegovina</option><option value="2072">Botswana</option><option value="2076">Brazil</option><option value="2084">Belize</option><option value="2090">Solomon Islands</option><option value="2096">Brunei</option><option value="2100">Bulgaria</option><option value="2104">Myanmar (Burma)</option><option value="2108">Burundi</option><option value="2112">Belarus</option><option value="2116">Cambodia</option><option value="2120">Cameroon</option><option value="2124">Canada</option><option value="2132">Cape Verde</option><option value="2140">Central African Republic</option><option value="2144">Sri Lanka</option><option value="2148">Chad</option><option value="2152">Chile</option><option value="2156">China</option><option value="2162">Christmas Island</option><option value="2166">Cocos (Keeling) Islands</option><option value="2170">Colombia</option><option value="2174">Comoros</option><option value="2178">Republic of the Congo</option><option value="2180">Democratic Republic of the Congo</option><option value="2184">Cook Islands</option><option value="2188">Costa Rica</option><option value="2191">Croatia</option><option value="2196">Cyprus</option><option value="2203">Czechia</option><option value="2204">Benin</option><option value="2208">Denmark</option><option value="2212">Dominica</option><option value="2214">Dominican Republic</option><option value="2218">Ecuador</option><option value="2222">El Salvador</option><option value="2226">Equatorial Guinea</option><option value="2231">Ethiopia</option><option value="2232">Eritrea</option><option value="2233">Estonia</option><option value="2239">South Georgia and the South Sandwich Islands</option><option value="2242">Fiji</option><option value="2246">Finland</option><option value="2250">France</option><option value="2258">French Polynesia</option><option value="2260">French Southern and Antarctic Lands</option><option value="2262">Djibouti</option><option value="2266">Gabon</option><option value="2268">Georgia</option><option value="2270">The Gambia</option><option value="2276">Germany</option><option value="2288">Ghana</option><option value="2296">Kiribati</option><option value="2300">Greece</option><option value="2308">Grenada</option><option value="2316">Guam</option><option value="2320">Guatemala</option><option value="2324">Guinea</option><option value="2328">Guyana</option><option value="2332">Haiti</option><option value="2334">Heard Island and McDonald Islands</option><option value="2336">Vatican City</option><option value="2340">Honduras</option><option value="2348">Hungary</option><option value="2352">Iceland</option><option value="2356">India</option><option value="2360">Indonesia</option><option value="2368">Iraq</option><option value="2372">Ireland</option><option value="2376">Israel</option><option value="2380">Italy</option><option value="2384">Cote d'Ivoire</option><option value="2388">Jamaica</option><option value="2392">Japan</option><option value="2398">Kazakhstan</option><option value="2400">Jordan</option><option value="2404">Kenya</option><option value="2410">South Korea</option><option value="2414">Kuwait</option><option value="2417">Kyrgyzstan</option><option value="2418">Laos</option><option value="2422">Lebanon</option><option value="2426">Lesotho</option><option value="2428">Latvia</option><option value="2430">Liberia</option><option value="2434">Libya</option><option value="2438">Liechtenstein</option><option value="2440">Lithuania</option><option value="2442">Luxembourg</option><option value="2450">Madagascar</option><option value="2454">Malawi</option><option value="2458">Malaysia</option><option value="2462">Maldives</option><option value="2466">Mali</option><option value="2470">Malta</option><option value="2478">Mauritania</option><option value="2480">Mauritius</option><option value="2484">Mexico</option><option value="2492">Monaco</option><option value="2496">Mongolia</option><option value="2498">Moldova</option><option value="2499">Montenegro</option><option value="2504">Morocco</option><option value="2508">Mozambique</option><option value="2512">Oman</option><option value="2516">Namibia</option><option value="2520">Nauru</option><option value="2524">Nepal</option><option value="2528">Netherlands</option><option value="2531">Curacao</option><option value="2534">Sint Maarten</option><option value="2535">Caribbean Netherlands</option><option value="2540">New Caledonia</option><option value="2548">Vanuatu</option><option value="2554">New Zealand</option><option value="2558">Nicaragua</option><option value="2562">Niger</option><option value="2566">Nigeria</option><option value="2570">Niue</option><option value="2574">Norfolk Island</option><option value="2578">Norway</option><option value="2580">Northern Mariana Islands</option><option value="2581">United States Minor Outlying Islands</option><option value="2583">Federated States of Micronesia</option><option value="2584">Marshall Islands</option><option value="2585">Palau</option><option value="2586">Pakistan</option><option value="2591">Panama</option><option value="2598">Papua New Guinea</option><option value="2600">Paraguay</option><option value="2604">Peru</option><option value="2608">Philippines</option><option value="2612">Pitcairn Islands</option><option value="2616">Poland</option><option value="2620">Portugal</option><option value="2624">Guinea-Bissau</option><option value="2626">Timor-Leste</option><option value="2634">Qatar</option><option value="2642">Romania</option><option value="2643" selected="selected">Russia</option><option value="2646">Rwanda</option><option value="2654">Saint Helena</option><option value="2659">Saint Kitts and Nevis</option><option value="2662">Saint Lucia</option><option value="2666">Saint Pierre and Miquelon</option><option value="2670">Saint Vincent and the Grenadines</option><option value="2674">San Marino</option><option value="2678">Sao Tome and Principe</option><option value="2682">Saudi Arabia</option><option value="2686">Senegal</option><option value="2688">Serbia</option><option value="2690">Seychelles</option><option value="2694">Sierra Leone</option><option value="2702">Singapore</option><option value="2703">Slovakia</option><option value="2704">Vietnam</option><option value="2705">Slovenia</option><option value="2706">Somalia</option><option value="2710">South Africa</option><option value="2716">Zimbabwe</option><option value="2724">Spain</option><option value="2740">Suriname</option><option value="2748">Swaziland</option><option value="2752">Sweden</option><option value="2756">Switzerland</option><option value="2762">Tajikistan</option><option value="2764">Thailand</option><option value="2768">Togo</option><option value="2772">Tokelau</option><option value="2776">Tonga</option><option value="2780">Trinidad and Tobago</option><option value="2784">United Arab Emirates</option><option value="2788">Tunisia</option><option value="2792">Turkey</option><option value="2795">Turkmenistan</option><option value="2798">Tuvalu</option><option value="2800">Uganda</option><option value="2804">Ukraine</option><option value="2807">Macedonia (FYROM)</option><option value="2818">Egypt</option><option value="2826">United Kingdom</option><option value="2831">Guernsey</option><option value="2832">Jersey</option><option value="2834">Tanzania</option><option value="2840">United States</option><option value="2854">Burkina Faso</option><option value="2858">Uruguay</option><option value="2860">Uzbekistan</option><option value="2862">Venezuela</option><option value="2876">Wallis and Futuna</option><option value="2882">Samoa</option><option value="2887">Yemen</option><option value="2894">Zambia</option></select>
			</td>
			</tr>
			<tr class="parser_google_data" style="display: none;">
	<th scope="row">Парсер Google, язык:</th>
	<td>
	<select name="parser_google_language"><option value="AF">AF</option><option value="AL">AL</option><option value="AQ">AQ</option><option value="DZ">DZ</option><option value="AS">AS</option><option value="AD">AD</option><option value="AO">AO</option><option value="AG">AG</option><option value="AZ">AZ</option><option value="AR">AR</option><option value="AU">AU</option><option value="AT">AT</option><option value="BS">BS</option><option value="BH">BH</option><option value="BD">BD</option><option value="AM">AM</option><option value="BB">BB</option><option value="BE">BE</option><option value="BT">BT</option><option value="BO">BO</option><option value="BA">BA</option><option value="BW">BW</option><option value="BR">BR</option><option value="BZ">BZ</option><option value="SB">SB</option><option value="BN">BN</option><option value="BG">BG</option><option value="MM">MM</option><option value="BI">BI</option><option value="BY">BY</option><option value="KH">KH</option><option value="CM">CM</option><option value="CA">CA</option><option value="CV">CV</option><option value="CF">CF</option><option value="LK">LK</option><option value="TD">TD</option><option value="CL">CL</option><option value="CN">CN</option><option value="CX">CX</option><option value="CC">CC</option><option value="CO">CO</option><option value="KM">KM</option><option value="CG">CG</option><option value="CD">CD</option><option value="CK">CK</option><option value="CR">CR</option><option value="HR">HR</option><option value="CY">CY</option><option value="CZ">CZ</option><option value="BJ">BJ</option><option value="DK">DK</option><option value="DM">DM</option><option value="DO">DO</option><option value="EC">EC</option><option value="SV">SV</option><option value="GQ">GQ</option><option value="ET">ET</option><option value="ER">ER</option><option value="EE">EE</option><option value="GS">GS</option><option value="FJ">FJ</option><option value="FI">FI</option><option value="FR">FR</option><option value="PF">PF</option><option value="TF">TF</option><option value="DJ">DJ</option><option value="GA">GA</option><option value="GE">GE</option><option value="GM">GM</option><option value="DE">DE</option><option value="GH">GH</option><option value="KI">KI</option><option value="GR">GR</option><option value="GD">GD</option><option value="GU">GU</option><option value="GT">GT</option><option value="GN">GN</option><option value="GY">GY</option><option value="HT">HT</option><option value="HM">HM</option><option value="VA">VA</option><option value="HN">HN</option><option value="HU">HU</option><option value="IS">IS</option><option value="IN">IN</option><option value="ID">ID</option><option value="IQ">IQ</option><option value="IE">IE</option><option value="IL">IL</option><option value="IT">IT</option><option value="CI">CI</option><option value="JM">JM</option><option value="JP">JP</option><option value="KZ">KZ</option><option value="JO">JO</option><option value="KE">KE</option><option value="KR">KR</option><option value="KW">KW</option><option value="KG">KG</option><option value="LA">LA</option><option value="LB">LB</option><option value="LS">LS</option><option value="LV">LV</option><option value="LR">LR</option><option value="LY">LY</option><option value="LI">LI</option><option value="LT">LT</option><option value="LU">LU</option><option value="MG">MG</option><option value="MW">MW</option><option value="MY">MY</option><option value="MV">MV</option><option value="ML">ML</option><option value="MT">MT</option><option value="MR">MR</option><option value="MU">MU</option><option value="MX">MX</option><option value="MC">MC</option><option value="MN">MN</option><option value="MD">MD</option><option value="ME">ME</option><option value="MA">MA</option><option value="MZ">MZ</option><option value="OM">OM</option><option value="NA">NA</option><option value="NR">NR</option><option value="NP">NP</option><option value="NL">NL</option><option value="CW">CW</option><option value="SX">SX</option><option value="BQ">BQ</option><option value="NC">NC</option><option value="VU">VU</option><option value="NZ">NZ</option><option value="NI">NI</option><option value="NE">NE</option><option value="NG">NG</option><option value="NU">NU</option><option value="NF">NF</option><option value="NO">NO</option><option value="MP">MP</option><option value="UM">UM</option><option value="FM">FM</option><option value="MH">MH</option><option value="PW">PW</option><option value="PK">PK</option><option value="PA">PA</option><option value="PG">PG</option><option value="PY">PY</option><option value="PE">PE</option><option value="PH">PH</option><option value="PN">PN</option><option value="PL">PL</option><option value="PT">PT</option><option value="GW">GW</option><option value="TL">TL</option><option value="QA">QA</option><option value="RO">RO</option><option value="RU" selected="selected">RU</option><option value="RW">RW</option><option value="SH">SH</option><option value="KN">KN</option><option value="LC">LC</option><option value="PM">PM</option><option value="VC">VC</option><option value="SM">SM</option><option value="ST">ST</option><option value="SA">SA</option><option value="SN">SN</option><option value="RS">RS</option><option value="SC">SC</option><option value="SL">SL</option><option value="SG">SG</option><option value="SK">SK</option><option value="VN">VN</option><option value="SI">SI</option><option value="SO">SO</option><option value="ZA">ZA</option><option value="ZW">ZW</option><option value="ES">ES</option><option value="SR">SR</option><option value="SZ">SZ</option><option value="SE">SE</option><option value="CH">CH</option><option value="TJ">TJ</option><option value="TH">TH</option><option value="TG">TG</option><option value="TK">TK</option><option value="TO">TO</option><option value="TT">TT</option><option value="AE">AE</option><option value="TN">TN</option><option value="TR">TR</option><option value="TM">TM</option><option value="TV">TV</option><option value="UG">UG</option><option value="UA">UA</option><option value="MK">MK</option><option value="EG">EG</option><option value="GB">GB</option><option value="GG">GG</option><option value="JE">JE</option><option value="TZ">TZ</option><option value="US">US</option><option value="BF">BF</option><option value="UY">UY</option><option value="UZ">UZ</option><option value="VE">VE</option><option value="WF">WF</option><option value="WS">WS</option><option value="YE">YE</option><option value="ZM">ZM</option></select>
			</td>
			</tr>


		<tr>
<th scope="row">Парсер Яндекс:</th>
<td>
<input type="checkbox" name="parser_yandex" value="yes" checked="checked">
		</td>
		</tr>
		
		
		</tbody>
		
		</table>

      	
		<p class="submit"><input type="submit" id="submitPost" class="button button-primary" value="Выполнить"></p>
	</div>
	</form>
	<?php
	}
	?>
	    <form action='options.php' method='post'>
	      <?php
if($_GET['tab']=='stories'){
	?>
	
	<div class="tabcontent">
<table class="widefat striped">

	
			<tbody>
        <?php
	
        showStories();
		
        ?>

</tbody></table>
	</div>
	<?php
	}
	
	
if($_GET['tab']=='settings'){
	?>
	
    <form action='options.php' method='post'>
	<div class="tabcontent">

        <?php
	

        settings_fields( 'SettingsAPIDofiltra' );
        do_settings_sections( 'SettingsAPIDofiltra' );


$send = (int)$wpdb->get_var( "SELECT COUNT(*) FROM ".$wpdb->postmeta." WHERE `meta_key` = 'id_dofiltra' AND `meta_value` != '';" );
$complated = (int)$wpdb->get_var( "SELECT COUNT(*) FROM ".$wpdb->postmeta." WHERE `meta_key` = 'completed_dofiltra' AND `meta_value` = '1';" );
$inproccess = $send - $complated;
?>

<tr>
<th scope="row">Всего отправлено:</th>
<td><?php echo $send; ?></td></tr><br><tr>
<th scope="row">В очереди:</th>
<td><?php echo $inproccess; ?></td></tr><br>
<tr>
<th scope="row">Выполнено:</th>
<td><?php echo $complated; ?></td></tr>
		<?php
		
			
        submit_button();
		
        ?>


	</div>
    </form>
	<?php
	}
	?>

    <?php
}
add_action( 'admin_menu', 'wpschool_api_add_admin_menu' );
add_action( 'admin_init', 'settings_notification_subs_init' );


//JS в админку
function add_js_file_subs($hook) {

    if ('toplevel_page_extractor-dofiltra' == $hook) {
        wp_enqueue_script('add_js_file_subs', plugin_dir_url(__FILE__) . '/js/main.js');
		wp_enqueue_style( 'add_css_file_subs', plugin_dir_url(__FILE__) . '/css/main.css');
		//Select2
		
        wp_enqueue_script('add_js_file_select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js');
		wp_enqueue_style( 'add_css_file_select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css');
		


    }else{
		return;
	}
    
}

add_action('admin_enqueue_scripts', 'add_js_file_subs');

register_activation_hook(__FILE__, 'extractor_dofiltra_activation');
function extractor_dofiltra_activation() {
	wp_clear_scheduled_hook( 'extractor_dofiltra_every_period_event_func_api_get_queue' );
	wp_schedule_event( time(), 'extractor_dofiltra_check_status_period', 'extractor_dofiltra_every_period_event_func_api_get_queue');
}

register_deactivation_hook( __FILE__, 'extractor_dofiltra_deactivation');
function extractor_dofiltra_deactivation() {
	wp_clear_scheduled_hook('extractor_dofiltra_every_period_event_func_api_get_queue');
}


 
add_filter( 'cron_schedules', 'extractor_dofiltra_cron_add_check_status_period' );
function extractor_dofiltra_cron_add_check_status_period( $schedules ) {
	$schedules['extractor_dofiltra_check_status_period'] = array(
		'interval' => 300,
		'display' => 'extractor_dofiltra_check_status_period'
	);
	return $schedules;
}

if( ! wp_next_scheduled( 'extractor_dofiltra_every_period_event_func_api_get_queue' ) ) { 
	wp_schedule_event( time(), 'extractor_dofiltra_check_status_period', 'extractor_dofiltra_every_period_event_func_api_get_queue');
}

add_action( 'wp_ajax_daft_update', 'extractor_dofiltra_every_period_event_func_api_get' );
add_action( 'wp_ajax_nopriv_daft_update', 'extractor_dofiltra_every_period_event_func_api_get' ); 


function extractor_dofiltra_every_period_event_func_api_get() {
  
	

 $options = get_option( 'settings_dofiltra_api' );
$APIdofiltra = new APIdofiltra($options['api_token']);

$args = array(
   'meta_query' => array(
       array(
           'key' => 'id_dofiltra',
           'compare' => 'EXISTS',
       )
   ),
   'posts_per_page' => -1,
   'post_status' => array( 'publish', 'private', 'pending', 'draft', 'future', 'trash' ),
   'post_type' => 'any',
);
$q = new WP_Query($args);

if( $q->have_posts() ) {
 	$ids = array();
 	$rqs = array();
 	$i = 0;
	while( $q->have_posts() ) { $q->the_post();
		$eod = get_post_meta( get_the_ID(), 'id_dofiltra', true );
		if ($i < 200 && get_post_meta(get_the_ID(), 'completed_dofiltra', 1) != '1' && $eod != '') {
			if (!isset($ids[floor($i / 20)])) {
				$ids[floor($i / 20)] = array();
			}
			$ids[floor($i / 20)][] = $eod;
			$rqs[$eod] = get_the_ID();
			$i++;
		}
	}
	$ra = array();
	$k = 0;
	foreach ($ids as $ids0) {
		$r = $APIdofiltra->getExtractStatuses($ids0);
		if (isset($r['result'])) {
 			foreach ($r['result'] as $rs) {
 				if ($rs['status'] == 9 && $k < 50) {
 					$ra[] = $rs['_id'];
 					$k++;
 				}
 			}
 		}
	}
 	foreach ($ra as $rb) {
 		getExcractPost($rqs[$rb], $rb);
 	}
}
 
wp_reset_postdata();
	
}


add_action( 'extractor_dofiltra_every_period_event_func_api_get_queue', 'extractor_dofiltra_every_period_event_func_api_get' );

 
 
 
//MetaBox
add_action( 'add_meta_boxes', 'adding_api_dofiltra_meta_boxes', 10, 2 );
function adding_api_dofiltra_meta_boxes( $post_type, $post ) {
	
	if(get_post_meta( $post->ID, 'id_dofiltra', true )){
	add_meta_box( 'my-meta-box', 'Данные парсинга', 'render_extract_meta_box', 'post', 'normal', 'default' );
	}
}

function render_extract_meta_box(){
	global $post;
	$UrlDofiltra = get_post_meta( $post->ID, '_dofiltra_urlsOrKeys', false );



	?>
	<div class="components-panel__row">
	<span>Ключи и ссылки:</span><div class="components-dropdown" tabindex="-1">
	<?php
	if($UrlDofiltra){
		foreach($UrlDofiltra[0] as $word){
		?>
	<?=$word?><br>
			<?php
 
	}
	}
	?>
	</div></div>

<hr>
		<?php
		$UrlDofiltra = 'https://ai.dofiltra.com/extractor/result/' . get_post_meta( $post->ID, 'id_dofiltra', true );
		?>
		
			<div class="components-panel__row">
	<span>История:</span><div class="components-dropdown" tabindex="-1">
	<a href="<?=$UrlDofiltra?>" target="_blank" class="components-button is-tertiary">Посмотреть
	</a>
	</div></div>
		<?php
}








