<?php

class APIdofiltra
{
    private $token;
    private $url;
    private $urlExtract;

    public function __construct($token) {
        $this->token = $token;
        $this->url = 'https://api.dofiltra.com/api/';
        $this->urlExtract = 'https://api.dofiltra.com/api/';
    }

    public function getBalance() {
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $this->url.'balance/get?token='.$this->token);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

        $output = curl_exec($ch);
        try {
        	$json = json_decode($output, true);
	
        	curl_close($ch);
	
        	return $json['coins'];
        } catch (Exception $e) {
        	return '';
        }
    }

    public function getStatistics() {
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $this->url.'stats/getRewritedCharsCount?token='.$this->token);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

        $output = curl_exec($ch);
        $json = json_decode($output, true);

        curl_close($ch);

        return $json['history'];
    }

    public function addRewrite($blocks, $force, $lang, $expand) {
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $this->url.'rewriteText/add');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
            'token' => $this->token,
            'targetLang' => $lang,
            'dataset' => 0,
            'power' => $force,
            'expand' => $expand,
            'blocks' => $blocks
        ], true));

        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Accept: application/json',
            'Content-Type: application/json'
        ));

        $output = curl_exec($ch);
        $json = json_decode($output, true);

        curl_close($ch);

        return $json;
    }

    public function getRewrite($id) {
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $this->url.'rewriteText/get?id='.$id.'&token='.$this->token);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

        $output = curl_exec($ch);
        $json = json_decode($output, true);

        curl_close($ch);

        return $json;
    }

    public function getExtract($id) {
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $this->url.'extractor/get?id='.$id.'&token='.$this->token);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

        $output = curl_exec($ch);
        $json = json_decode($output, true);

        curl_close($ch);

        return $json;
    }

    public function getExtractStatuses($ids) {
        $ch = curl_init();
		$null_req = [];
        curl_setopt($ch, CURLOPT_URL, $this->url.'extractor/getStatuses');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
            'token' => $this->token,
            'ids' => $ids,
        ], true));

        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Accept: application/json',
            'Content-Type: application/json',
			
        ));

        $output = curl_exec($ch);
        $json = json_decode($output, true);

        curl_close($ch);

        return $json;
    }

    public function addExtract($urlsOrKeysGroups,$contentOpts,$duplicateOpts,$googleParserOpts,$yandexParserOpts) {
        $ch = curl_init();
		$null_req = [];
		$pq = array();
		foreach ($urlsOrKeysGroups as $urlsOrKeys) {
			$pq[] = [
            	'token' => $this->token,
            	'urlsOrKeys' => $urlsOrKeys,
				'contentOpts' => $contentOpts,
				'typographOpts' => $typographOpts,
				'duplicateOpts' => $duplicateOpts,
				'googleParserOpts' => $googleParserOpts,
				'yandexParserOpts' => $yandexParserOpts
        	];
		}
		$typographOpts = ['removeSelectors'=>[],'removeAttrs'=>['a[href]'=>['href','onload']],'replaceTags'=>['a'=>'span']];
        curl_setopt($ch, CURLOPT_URL, $this->url.'extractor/add');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($pq, true));

        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Accept: application/json',
            'Content-Type: application/json',
			
        ));

        $output = curl_exec($ch);
        $json = json_decode($output, true);

        curl_close($ch);

        return $json;
    }

    public function addExtractOld($urlsOrKeys,$contentOpts,$duplicateOpts,$googleParserOpts,$yandexParserOpts) {
        $ch = curl_init();
		$null_req = [];
		$typographOpts = ['removeSelectors'=>[],'removeAttrs'=>['a[href]'=>['href','onload']],'replaceTags'=>['a'=>'span']];
        curl_setopt($ch, CURLOPT_URL, $this->url.'extractor/add');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([[
            'token' => $this->token,
            'urlsOrKeys' => $urlsOrKeys,
			'contentOpts' => $contentOpts,
			'typographOpts' => $typographOpts,
			'duplicateOpts' => $duplicateOpts,
			'googleParserOpts' => $googleParserOpts,
			'yandexParserOpts' => $yandexParserOpts
        ]], true));

        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Accept: application/json',
            'Content-Type: application/json',
			
        ));

        $output = curl_exec($ch);
        $json = json_decode($output, true);

        curl_close($ch);

        return $json;
    }
}
