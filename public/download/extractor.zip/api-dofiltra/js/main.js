function changeTabSetting(evt, tabName) {
  // Declare all variables
  var i, tabcontent, tablinks;

  // Get all elements with class="tabcontent" and hide them
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }

  // Get all elements with class="tablinks" and remove the class "active"
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }

  // Show the current tab, and add an "active" class to the button that opened the tab
  document.getElementById(tabName).style.display = "block";
  evt.currentTarget.className += " active";
  
}
window.addEventListener("load", function() {
//document.getElementById("subscribesTab").click();
jQuery('.js-products-multiple').select2();
jQuery('#ungroup').click(function() {
	
	var keyLink = jQuery('#keyLink').val();

var result = keyLink.replace(/(?:\r\n|\r|\n)/gi,"\n\n"); 
var result = result.replace(/,|;|\t/g,"\n"); 
result = result.split(String.fromCharCode(9)).join('\n')



jQuery('#keyLink').val(result);
  
  
});

jQuery('#submitPost').click(function() {

jQuery('#submitPost').val('Ожидайте...');







});



jQuery(document).delegate('#keyLink', 'keydown', function(e) {
  var keyCode = e.keyCode || e.which;
  if (keyCode == 9) {
    e.preventDefault();
    var start = this.selectionStart;
    var end = this.selectionEnd;
    var text = jQuery(this).val();
    var selText = text.substring(start, end);
    jQuery(this).val(
      text.substring(0, start) +
      "\t" + selText.replace(/\n/g, "\n\t") +
      text.substring(end)
    );
    this.selectionStart = this.selectionEnd = start + 1;
  }
});






});
