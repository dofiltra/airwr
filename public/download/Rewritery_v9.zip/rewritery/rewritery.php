<?php

/*
Plugin Name: Rewritery
Description: Developed for rewriting posts texts by using ai.dofiltra API
Version: 1.0.0
Author: vladislv31
Author URI: https://github.com/vladislv31
License: GPLv2 or later
Text Domain: rewritery
*/

if (!function_exists('add_action')) die('Hhmmm.....');

class Rewritery
{

    function replace_content($content)
    {
        $content = str_replace('&nbsp;', ' ', $content);
        return $content;
    }
    
    function add_iframe($initArray) {
        $initArray['extended_valid_elements'] = "iframe[id|class|title|style|align|frameborder|height|longdesc|marginheight|marginwidth|name|scrolling|src|width]";
        return $initArray;
    }

    public function register() {
        add_filter('the_content', [$this, 'replace_content']);

        // enqueue admin
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_front']);

        // add menu admin
        add_action('admin_menu', [$this, 'add_admin_menu']);

        add_action('admin_init', [$this, 'settings_init']);

        // meta boxes
        add_action('add_meta_boxes', [$this, 'post_meta_boxes']);

        // ajax actions
        add_action('wp_ajax_add-rewrite', [$this, 'add_rewrite_callback']);
        // add_action('wp_ajax_rewrite-cron', [$this, 'rewrite_cron_callback']);

        // add_action('edit_post', [$this, 'change_rewritery_status'], 10, 2);


        // embed filters
        
        // add_filter('content_save_pre', 'wp_filter_post_kses');
        // add_filter('excerpt_save_pre', 'wp_filter_post_kses');
        // add_filter('content_filtered_save_pre', 'wp_filter_post_kses');
        
        add_filter('tiny_mce_before_init', [$this, 'add_iframe']);


        // register cron
        add_action('wp', [$this, 'cronstarter_activation']);
        register_deactivation_hook(__FILE__, [$this, 'rewritery_deactivate']);
        add_action('rewritery_cron_job', [$this, 'rewrite_cron_callback']);
        add_filter('cron_schedules', [$this, 'cron_add_minute']);


        // post list columns
        add_filter('manage_post_posts_columns', function($columns) {
            return array_merge($columns, ['rewritery_status' => 'Статус реврайта', 'rewritery_date' => 'Последний реврайт', 'rewritery_result' => 'Результат']);
        });
         
        add_action('manage_post_posts_custom_column', function($column_key, $post_id) {
            if ($column_key == 'rewritery_status') {
                $status = get_post_meta($post_id, 'rewritery_status', true);
                $status = $status ? $status : 'не реврайчено';
                echo ucfirst($status);
            } else if ($column_key == 'rewritery_date') {
                $date = get_post_meta($post_id, 'rewritery_last_date', true);
                $date = $date ? $date : 'Еще не реврайчено';
                echo $date;
            } else if ($column_key == 'rewritery_result') {
                $rewrite_id = get_post_meta($post_id, 'rewritery_rewrite_id', true);
                if ($rewrite_id) {
                    echo '<a target="_blank" href="https://ai.dofiltra.com/rewrite/result/'.$rewrite_id.'">Посмотреть</a>';
                } else {
                    echo '—';
                }
            }
        }, 1, 2);

        // post list actions
        add_filter('bulk_actions-edit-post', function($bulk_actions) {
            $bulk_actions['rewritery-rewrite'] = 'Зареврайтить';
            return $bulk_actions;
        });

        add_filter('handle_bulk_actions-edit-post', function($redirect_url, $action, $post_ids) {
            if ($action == 'rewritery-rewrite') {
                $error = null;

                foreach ($post_ids as $post_id) {
                    $res = $this->rewrite_post($post_id);

                    if ($res['error'] != null) {
                        $error = $res['error'];
                        break;
                    }
                }

                if ($error) {
                    $redirect_url = add_query_arg('rewritery_bulk_error', $error, $redirect_url);
                }
            }
            return $redirect_url;
        }, 10, 3);

        // error

        add_action('admin_notices', [$this, 'rewritery_error_notice']);
    }

    function rewritery_error_notice() {
        if (isset($_REQUEST['rewritery_bulk_error'])) {
            ?>

                <div id="message" class="error">
                    <p><?php echo $_REQUEST['rewritery_bulk_error']; ?></p>
                </div>

            <?php
        }
    }

    public function enqueue_admin() {
        wp_enqueue_style('rewriteryStyle', plugins_url('/assets/admin/styles.css', __FILE__));
        wp_enqueue_script('rewriteryScript', plugins_url('/assets/admin/scripts.js', __FILE__));
    }

    public function enqueue_front() {
        wp_enqueue_style('rewriteryStyle', plugins_url('/assets/front/styles.css', __FILE__));
        wp_enqueue_script('rewriteryScript', plugins_url('/assets/front/scripts.js', __FILE__));
    }

    public function add_admin_menu() {
        add_menu_page(
            esc_html__('Настройки Rewritery', 'rewritery'),
            esc_html__('Rewritery', 'rewritery'),
            'manage_options',
            'rewritery_settings',
            [$this, 'rewritery_page'],
            'dashicons-welcome-write-blog',
            100
        );
    }

    public function rewritery_page() {
        require_once plugin_dir_path(__FILE__).'admin/admin.php';
    }

    public function settings_init() {
        register_setting('rewritery_settings', 'rewritery_settings_options');
        add_settings_section('rewritery_settings_section', 'Настройки', [$this, 'settings_section_html'], 'rewritery_settings');

        add_settings_field('api_token', 'API токен', [$this, 'api_token_html'], 'rewritery_settings', 'rewritery_settings_section');

        add_settings_field('api_force', 'Сила реврайта', [$this, 'api_force_html'], 'rewritery_settings', 'rewritery_settings_section');

        add_settings_field('api_mode', 'Мод реврайта', [$this, 'api_mode_html'], 'rewritery_settings', 'rewritery_settings_section');

        add_settings_field('api_lang', 'Язык реврайта', [$this, 'api_lang_html'], 'rewritery_settings', 'rewritery_settings_section');
    }

    public function settings_section_html() {
        // echo esc_html__('Hello, world!', 'rewritery');
    }

    public function api_token_html() {
        $options = get_option('rewritery_settings_options');

        ?>

            <input type="text" name="rewritery_settings_options[api_token]" value="<?php echo isset($options['api_token']) ? $options['api_token'] : ''; ?>">

        <?php

        if ($options['api_token']) {
            require_once plugin_dir_path(__FILE__).'api.php';

            $api = new API($options['api_token']);
            $balance = $api->getBalance();

            ?>

                <p>Баланс токена: <strong><?php echo $balance; ?></strong> монет</p>

            <?php
        }
    }

    public function api_force_html() {
        $options = get_option('rewritery_settings_options');

        $force = 0.5;
        if (isset($options['api_force'])) {
            $force = floatval($options['api_force']);
            if ($force < 0) $force = 0;
            if ($force > 1) $force = 1;
        }

        $options['api_force'] = $force;
        update_option('rewritery_settings_options', $options);

        ?>

            <input type="text" name="rewritery_settings_options[api_force]" value="<?php echo $force; ?>">
            <p>Число от 0 до 1 включительно</p>

        <?php

    }

    public function api_mode_html() {
        $options = get_option('rewritery_settings_options');
        $modes = array("Shorter", "Longer");

        echo "<select id='api_mode' name='rewritery_settings_options[api_mode]'>";
        foreach($modes as $mode) {
            $selected = ($options['api_mode']==$mode) ? 'selected="selected"' : '';
            echo "<option value='$mode' $selected>$mode</option>";
        }
        echo "</select>";

    }

    public function api_lang_html() {
        $options = get_option('rewritery_settings_options');

        if (!$options['api_lang']) {
            $options['api_lang'] = 'RU';
            update_option('rewritery_settings_options', $options);
        }

        $modes = array('RU', 'EN', 'BG', 'ZH', 'CS', 'DA', 'NL', 'ET', 'FI', 'FR', 'DE', 'EL', 'HU', 'IT', 'JA', 'LV', 'LT', 'PL', 'PT', 'RO', 'SK', 'SL', 'ES', 'SV');

        echo "<select id='api_lang' name='rewritery_settings_options[api_lang]'>";
        foreach($modes as $mode) {
            $selected = ($options['api_lang']==$mode) ? 'selected="selected"' : '';
            echo "<option value='$mode' $selected>$mode</option>";
        }
        echo "</select>";

    }

    public function post_meta_boxes() {
        add_meta_box(
            'rewritery_metabox',
            'Настройки реврайта',
            [$this, 'rewritery_metabox_callback'],
            'post',
            'normal',
            'default'
        );
    }

    public function rewritery_metabox_callback($post) {
        $id = $post->ID;
        $status = get_post_meta($id, 'rewritery_status', true) ? get_post_meta($id, 'rewritery_status', true) : 'не реврайчено';
        $rewrite_id = get_post_meta($id, 'rewritery_rewrite_id', true);

        ?>

            <div class="rewritery-post-settings" id="rewritery_block">
                <p>Статус реврайта: <b><?php echo $status; ?></b></p>
                <a href="/wp-admin/admin-ajax.php?action=add-rewrite&post_id=<?php echo $id; ?>&redirect_url=<?php echo urlencode($_SERVER['REQUEST_URI']); ?>" class="components-button is-primary rewritery-add-button">Зареврайтить</a>
                <?php
                
                    if ($rewrite_id) {
                        echo '<p><a target="_blank" href="https://ai.dofiltra.com/rewrite/result/'.$rewrite_id.'">Посмотреть результат</a></p>';   
                    }

                    $error = get_post_meta($id, 'rewritery_error', true);
                    if ($error) {
                        ?>

                            <div class="rewritery_error">
                                <p><?php echo $error; ?></p>
                            </div>
                        
                        <?php

                        delete_post_meta($id, 'rewritery_error');
                    }

                ?>
            </div>

        <?php
    }

    public function add_rewrite_callback() {
        $id = $_GET['post_id'];
        $rd_url = $_GET['redirect_url'];

        if (get_post_status($id)) {
            $res = $this->rewrite_post($id);

            if ($res['error'] != null) {
                update_post_meta($id, 'rewritery_error', $res['error']);
            }

            wp_redirect(get_site_url().'/wp-admin/post.php?post='.$id.'&action=edit');
            exit();
        }

        wp_die();
    }

    public function recursion($doc, &$blocks, &$html) {
        foreach (pq($doc)->find('*') as $el) {
            if (pq($el)->text() == '') {
                $this->recursion($el, $blocks, $content);
            } else {
                if (in_array($el->tagName, ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'])) {
                    $to_replace = (string)(pq($el));
                    $to_replace = preg_replace('/\>\s+\</m', '><', $to_replace);
                    $to_replace = htmlspecialchars($to_replace);

                    $old_html = $html;
                    
                    $pos = strpos($html, $to_replace);
                    if ($pos !== false) {
                        $html = substr_replace($html, '<h' . str_replace('h', '', $el->tagName) . '>{{ header }}</h' . str_replace('h', '', $el->tagName) . '>', $pos, strlen($to_replace));
                    }
                    
                    if ($old_html != $html) {
                        $blocks[] = [
                            'type' => 'header',
                            'data' => [
                                'text' => pq($el)->text(),
                                'level' => str_replace('h', '', $el->tagName)
                            ]
                        ];
                    }
                } else if ($el->tagName == 'p') {
                    $to_replace = (string)(pq($el));
                    $to_replace = preg_replace('/\>\s+\</m', '><', $to_replace);
                    $to_replace = htmlspecialchars($to_replace);

                    $old_html = $html;
                    
                    $pos = strpos($html, $to_replace);
                    if ($pos !== false) {
                        $html = substr_replace($html, '<p>{{ paragraph }}</p>', $pos, strlen($to_replace));
                    }
                    
                    if ($old_html != $html) {
                        $blocks[] = [
                            'type' => 'paragraph',
                            'data' => [
                                'text' => pq($el)->text()
                            ]
                        ];
                    }
                } else if (in_array($el->tagName, ['ul', 'ol'])) {
                    $style = 'ordered';
                    if ($el->tagName == 'ul') {
                        $style = 'unordered';
                    }
        
                    $lis = pq($el)->find('li');
                    $items = [];
        
                    foreach ($lis as $li) {
                        $items[] = pq($li)->text();
                    }
                    
                    $to_replace = (string)(pq($el));
                    $to_replace = preg_replace('/\>\s+\</m', '><', $to_replace);
                    $to_replace = htmlspecialchars($to_replace);
                    
                    $old_html = $html;
                    
                    if ($style == 'ordered') {
                        $pos = strpos($html, $to_replace);
                        if ($pos !== false) {
                            $html = substr_replace($html, '<ol>{{ list }}</ol>', $pos, strlen($to_replace));
                        }
                    } else {
                        $pos = strpos($html, $to_replace);
                        if ($pos !== false) {
                            $html = substr_replace($html, '<ul>{{ list }}</ul>', $pos, strlen($to_replace));
                        }
                    }
        
                    if ($old_html != $html) {
                        $blocks[] = [
                            'type' => 'list',
                            'data' => [
                                'style' => $style,
                                'items'=> $items
                            ]
                        ];
                    }
                }
            }
        }
    }

    public function rewrite_post($id) {
        require_once plugin_dir_path(__FILE__).'libs/phpQuery.php';

        $options = get_option('rewritery_settings_options');

        $force = 0.5;
        if (isset($options['api_force'])) {
            $force = floatval($options['api_force']);
            if ($force < 0) $force = 0;
            if ($force > 1) $force = 1;
        }

        $lang = 'RU';
        if ($options['api_lang']) {
            $lang = $options['api_lang'];
        }

        $mode = 'Shorter';
        if ($options['api_mode']) {
            $mode = $options['api_mode'];
        }
        $mode = strtoupper($mode);
        
        

        $content_post = get_post($id);
        $content = $content_post->post_content;
        // $content = apply_filters('the_content', $content);
        $content = wpautop($content);
        $content = str_replace(']]>', ']]&gt;', $content);
        
        $content = preg_replace('/\>\s+\</m', '><', $content);

        $doc = phpQuery::newDocument($content);

        $blocks = [];
        $images_html = [];

        $content = htmlspecialchars($content);
        
        $this->recursion($doc, $blocks, $content);
        
        $content = htmlspecialchars_decode($content);

        require_once plugin_dir_path(__FILE__).'api.php';

        $api = new API($options['api_token']);
        $res = $api->addRewrite($blocks, $force, $lang, $mode);
        
        if ($res['error']) {
            return $res;
        } else {
            $rewrite_id = $res['result']['_id'];
            update_post_meta($id, 'rewritery_rewrite_id', $rewrite_id);
            update_post_meta($id, 'rewritery_status', 'в процессе');
            update_post_meta($id, 'rewritery_temp_content', $content);

            return $res;
        }
    }

    public function rewrite_cron_callback() {
        $options = get_option('rewritery_settings_options');

        require_once plugin_dir_path(__FILE__).'api.php';
        $api = new API($options['api_token']);

        $args = array(
            'meta_key' => 'rewritery_status',
            'meta_query' => array(
                array(
                    'key' => 'rewritery_status',
                    'value' => 'в процессе',
                    'compare' => '=',
                )
            ),
            'post_status' => 'any',
            'post_type' => 'post'
         );

        $query = new WP_Query($args);

        while($query->have_posts()) {
            $query->the_post();
            $id = get_the_ID();

            $rewrite_id = get_post_meta($id, 'rewritery_rewrite_id', true);
            $rewrites = $api->getRewrite($rewrite_id);

            if ($rewrites != null) {
                if ($rewrites['item'] != null) {
                    if ($rewrites['item']['status'] == 9) {
                        $temp_content = get_post_meta($id, 'rewritery_temp_content', true);

                        foreach($rewrites['item']['blocks'] as $block) {
                            $type = $block['type'];
                         
                            if (in_array($type, ['header', 'paragraph', 'list'])) {
                                if ($type == 'header') {
                                    if ($block['rewriteDataSuggestions']) {
                                        $new_data = $block['rewriteDataSuggestions'][0]['text'];
                                    } else {
                                        $new_data = $block['data']['text'];
                                    }

                                    $pos = strpos($temp_content, '{{ header }}');
                                    if ($pos !== false) {
                                        $temp_content = substr_replace($temp_content, $new_data, $pos, strlen('{{ header }}'));
                                    }

                                } else if ($type == 'paragraph') {
                                    if ($block['rewriteDataSuggestions']) {
                                        $new_data = $block['rewriteDataSuggestions'][0]['text'];
                                    } else {
                                        $new_data = $block['data']['text'];
                                    }

                                    $pos = strpos($temp_content, '{{ paragraph }}');
                                    if ($pos !== false) {
                                        $temp_content = substr_replace($temp_content, $new_data, $pos, strlen('{{ paragraph }}'));
                                    }
                                } else if ($type == 'list') {
                                    $items = $block['data']['items'];
                                    if ($block['rewriteDataSuggestions']) {
                                        $items = $block['rewriteDataSuggestions'][0]['items'];
                                    }
                                    
                                    $list_items_html = '';

                                    foreach ($items as $itm) {
                                        $list_items_html .= '<li>'.$itm.'</li>';
                                    }
                                    
                                    $pos = strpos($temp_content, '{{ list }}');
                                    if ($pos !== false) {
                                        $temp_content = substr_replace($temp_content, $list_items_html, $pos, strlen('{{ list }}'));
                                    }
                                }
                            }
                        }

                        // require_once plugin_dir_path(__FILE__).'libs/phpQuery.php';
                        // $doc = phpQuery::newDocument($temp_content);
                        // $doc->find('div.flat_pm_start')->remove();
                        // $doc->find('div.flat_pm_end')->remove();
                        
                        // file_put_contents(plugin_dir_path( __FILE__ ).'/test.txt', $temp_content);
                        
                        kses_remove_filters();
                        
                        $post = get_post($id);
                        $post->post_content = $temp_content;
                        wp_update_post($post);
                        
                        kses_init_filters();
        
                        delete_post_meta($id, 'rewritery_temp_content');
                        update_post_meta($id, 'rewritery_status', 'зареврайчено');
                        update_post_meta($id, 'rewritery_last_date', current_time('d m Y H:i'));
                    }
                }
            }
        }

        wp_reset_postdata();
        wp_die();
    }

    public function change_rewritery_status($post_ID, $post) {
        delete_post_meta($post_ID, 'rewritery_status');
    }

    function cronstarter_activation() {
        if (!wp_next_scheduled('rewritery_cron_job')) {  
            wp_schedule_event(time(), 'everyminute', 'rewritery_cron_job');  
        }
    }

    function rewritery_deactivate() {	
        $timestamp = wp_next_scheduled('rewritery_cron_job');
        wp_unschedule_event($timestamp, 'rewritery_cron_job');

        global $wpdb;

        $table = $wpdb->prefix.'postmeta';

        $wpdb->delete($table, array('meta_key' => 'rewritery_status'));
        $wpdb->delete($table, array('meta_key' => 'rewritery_rewrite_id'));
        $wpdb->delete($table, array('meta_key' => 'rewritery_error'));
    }

    function cron_add_minute($schedules) {
        $schedules['everyminute'] = array(
            'interval' => 60,
            'display' => __( 'Once Every Minute' )
        );

        return $schedules;
    }
}

if (class_exists('Rewritery')) {
    $rewritery = new Rewritery();
    $rewritery->register();
}
