<?php
 
/**
 * Plugin Name: Ai.Dofiltra Translator
 * Description: Polylang API ai.dofiltra.com
 * Version: 1.0.7
 * Author: ktanster
 * Author URI: https://kwork.ru/user/ktanster
 */
 


 
if ( ! defined( 'WPINC' ) ) {
 
    die;
 
}

if ( in_array( 'polylang/polylang.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	add_action('admin_menu', 'kt680651_add_plugin_page');
	function kt680651_add_plugin_page(){
		add_options_page( 'AI Rewriter Translate', 'AI Rewriter Translate', 'manage_options', 'kt680651_apiai', 'kt680651_options_page_output' );
	}
	
	function kt680651_options_page_output(){
		?>
		<div class="wrap">
			<h2><?php echo get_admin_page_title() ?></h2>
			<form action="options.php" method="POST">
				<?php
					settings_fields( 'kt680651_st' );
					do_settings_sections( 'kt680651_page' );
					submit_button();
				?>
			</form>
		</div>
		<?php
	}
	
	add_action('admin_init', 'kt680651_plugin_settings');
	function kt680651_plugin_settings(){
		global $kt680651_apikey;
		register_setting( 'kt680651_st', 'kt680651_apikey', 'kt680651_sanitize_callback' );
		register_setting( 'kt680651_st', 'kt680651_debug', 'kt680651_sanitize_callback' );
		add_settings_section( 'kt680651_section1', 'Настройки API', '', 'kt680651_page' ); 
	
		add_settings_field('kt680651_field1', 'Токен', 'fill_kt680651_field1', 'kt680651_page', 'kt680651_section1' );
		add_settings_field('kt680651_field2', 'Отладка', 'fill_kt680651_field2', 'kt680651_page', 'kt680651_section1' );
	}
	
	function fill_kt680651_field1(){
		$val = get_option('kt680651_apikey');
		$val = $val ? $val['input'] : null;
		?>
		<label><input type="text" name="kt680651_apikey[input]" value="<?php echo esc_attr( $val ) ?>" /></label>
		<?php
		if (!empty($val)) { ?>
			<br />Баланс: <b><?php echo esc_html(json_decode(kt680651_sendAPIget('https://api.dofiltra.com/api/balance/get'), 1)['coins']); ?></b><br />
			Статистика:<br/>
			<?php 
			$stats = json_decode(kt680651_sendAPIget('https://api.dofiltra.com/api/stats/getRewritedCharsCount'), 1)['history'];
			foreach ($stats as $month => $stat) {
				echo esc_html($month).': <b>'.esc_html($stat).'</b><br />';
			}
			 ?>
		<?php } else {echo '<br /><a href="https://ai.dofiltra.com/info/api" target="_blank">Получить токен</a>';}
	}
	
	function fill_kt680651_field2(){
		$val = get_option('kt680651_debug');
		$val = $val ? $val['input'] : null;
		if ($val == 'yes') {
			$chk = true;
		} else {
			$chk = false;
		}
		?>
		<label><input type="checkbox" name="kt680651_debug[input]" value="yes"<?php if ($chk) { ?> checked<?php } ?> /> Включить</label>
			<br />Файл отладки: <code><?php echo $_SERVER['DOCUMENT_ROOT'].'/kt680651_debug.log'; ?></code><br />Токен в файл отладки не записывается
		<?php
	}
	
	function kt680651_sanitize_callback( $options ){ 
		foreach( $options as $name => & $val ){
			if( $name == 'input' ) {
				$val = strip_tags( $val );
			}
			if( $name == 'lastinput' ) {
				$val = strip_tags( $val );
			}
			
			if( $name == 'inputs' ) {
				$val = strip_tags( $val );
			}
			
			if( $name == 'checkbox' ) {
				$val = intval( $val );
			}
		}
	
		return $options;
	}
	
	function kt680651_debug_log($title, $text) {
		$val = get_option('kt680651_debug');
		$val = $val ? $val['input'] : null;
		if ($val == 'yes') {
			$chk = true;
		} else {
			$chk = false;
		}
		if ($chk) {
			$df = $_SERVER['DOCUMENT_ROOT'].'/kt680651_debug.log';
			if (!file_exists($df)) {
				$dft = fopen($df, 'w');
				fwrite($dft, 'Ai.Dofiltra Translator Debug Log'.chr(10).chr(10));
			} else {
				$dft = fopen($df, 'a');
			}
			fwrite($dft, date('Y-m-d H:i:s').': '.$title.chr(10).$text.chr(10).chr(10));			
			fclose($dft);
		}
	}
	
	$kt680651_apikey = get_option('kt680651_apikey', array('input' => ''))['input'];
	
	function kt680651_sendAPIget($url){
		global $kt680651_apikey;
		$url0 = $url;
		if (strpos($url, '?') !== false) {
			$url = $url.'&token='.urlencode($kt680651_apikey);
		} else {
			$url = $url.'?token='.urlencode($kt680651_apikey);
		}
		if (strpos($url0, '?') !== false) {
			$url0 = $url0.'&token=APITOKEN';
		} else {
			$url0 = $url0.'?token=APITOKEN';
		}
    	$ch = curl_init($url);
    	$options = array(
    		CURLOPT_RETURNTRANSFER => true,
    		CURLOPT_HEADER         => true,
    		CURLOPT_FOLLOWLOCATION => false,
    		CURLOPT_NOBODY => false,
    		CURLOPT_HTTPHEADER => array('Accept: application/json', 'Content-Type: application/json'),
    		CURLOPT_ENCODING       => "",
    		CURLOPT_USERAGENT      => $_SERVER['HTTP_USER_AGENT'],
    		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    		CURLOPT_AUTOREFERER    => false,
    		CURLOPT_CONNECTTIMEOUT => 120,
    		CURLOPT_TIMEOUT        => 120,
    		CURLOPT_MAXREDIRS      => 10,
    		CURLOPT_SSL_VERIFYPEER => false
		);
		curl_setopt_array( $ch, $options );
    	$html = curl_exec($ch);
    	$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    	$header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
		$headerstring = substr($html, 0, $header_size);
		$html = substr($html, $header_size);
		curl_close($ch);
		kt680651_debug_log('HTTP GET '.$url0.' - '.$http_code, 'Response:'.chr(10).str_replace($kt680651_apikey, 'API_TOKEN', $html));
    	return $html;
	}	
	
	function kt680651_sendAPIpost($url, $arr){
		global $kt680651_apikey;
		$arr['token'] = $kt680651_apikey;
    	$ch = curl_init($url);
    	$options = array(
    		CURLOPT_RETURNTRANSFER => true,
    		CURLOPT_HEADER         => true,
    		CURLOPT_FOLLOWLOCATION => false,
    		CURLOPT_NOBODY => false,
    		CURLOPT_POSTFIELDS => json_encode($arr, JSON_UNESCAPED_UNICODE),
    		CURLOPT_HTTPHEADER => array('Content-Type: application/json'),
    		CURLOPT_POST => true,
    		CURLOPT_ENCODING       => "",
    		CURLOPT_USERAGENT      => $_SERVER['HTTP_USER_AGENT'],
    		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    		CURLOPT_AUTOREFERER    => false,
    		CURLOPT_CONNECTTIMEOUT => 120,
    		CURLOPT_TIMEOUT        => 120,
    		CURLOPT_MAXREDIRS      => 10,
    		CURLOPT_SSL_VERIFYPEER => false
		);
		curl_setopt_array( $ch, $options );
    	$html = curl_exec($ch);
    	$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    	$header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
		$headerstring = substr($html, 0, $header_size);
		$html = substr($html, $header_size);
		curl_close($ch);
		$arr['token'] = 'API_TOKEN';
		kt680651_debug_log('HTTP POST '.$url.' - '.$http_code, 'Request:'.chr(10).json_encode($arr, JSON_UNESCAPED_UNICODE).chr(10).'Response:'.chr(10).str_replace($kt680651_apikey, 'API_TOKEN', $html));
    	return $html;
	}
	
	add_filter( 'bulk_actions-edit-post', 'kt680651_register_bulk_actions' );
	
	function kt680651_register_bulk_actions($bulk_actions) {
		global $kt680651_apikey;
		if (!empty($kt680651_apikey)) {
			$bulk_actions['kt680651_bulk'] = 'Перевести';
		}
		return $bulk_actions;
	}
	
	add_filter('handle_bulk_actions-edit-post', 'kt680651_handle_bulk_actions', 10, 3);
	
	function kt680651_handle_bulk_actions($redirect_url, $action, $post_ids) {
		if ($action == 'kt680651_bulk') {
			foreach ($post_ids as $post_id) {
				$s = get_post_meta($post_id, 'kt680651_status_translate', 1);
        		if (empty($s) || $s == '9') {
        			if (pll_get_post_language( $post_id, 'slug' ) == 'ru') {
						kt680651_translate_post($post_id);
					}
				}
			}
		}
		return $redirect_url;
	}
	
	add_filter( 'manage_post_posts_columns', 'kt680651_posts_columns' );
	
	function kt680651_posts_columns( $columns ) {
		global $kt680651_apikey;
		if (!empty($kt680651_apikey)) {
			$c = array();
			foreach ($columns as $key => $val) {
				$c[$key] = $val;
				if ($key == 'tags') {
					$c['kt680651_status'] = 'Статус перевода';
				}
			}
			$columns = $c;
			if (!isset($columns['kt680651_status'])) {
  				$columns['kt680651_status'] = 'Статус перевода';
  			}
  		}
  		return $columns;
	}

	add_filter( 'manage_post_posts_columns', 'kt680651_posts_columns' );
	
	add_action( 'manage_post_posts_custom_column', 'kt680651_columns_post', 10, 2);
	
	function kt680651_columns_post( $column, $post_id ) {
  		if ( 'kt680651_status' === $column ) {
			if (pll_get_post_language( $post_id, 'slug' ) == 'ru') {
        		$s = get_post_meta($post_id, 'kt680651_status_translate', 1);
        		if ($s == '') {
        			$p = 'Не переведено<br /><a href="#" onclick="kt680651_translate_post('.esc_html($post_id).', this); return false;">Перевести</a>';
        		} elseif ($s == 'queue') {
        			$p = 'В очереди';
        		} elseif ($s == '0') {
        			$p = 'Ожидание перевода';
        		} elseif ($s == '3') {
        			$p = 'Переводится';
        		} elseif ($s == '9') {
        			$p = 'Переведено<br /><a href="https://ai.dofiltra.com/translator/result/'.esc_html(get_post_meta($post_id, 'kt680651_id_translate', 1)).'" target="_blank">Результат</a><br /><a href="#" onclick="kt680651_translate_post('.esc_html($post_id).', this); return false;">Перевести ещё раз</a>';
        		} 
        		echo $p;
        	}
  		}
	}
	
	function kt680651_action_in_min() {
		$time6sec_a = floor((int)date('U') / 60);
		$time6sec_b = (int)get_option('kt680651_timemin', '-1');
		if ($time6sec_a == $time6sec_b) {
			$a = (int)get_option('kt680651_actionsinmin', '0');
			$r = $a + 1;
			update_option('kt680651_actionsinmin', (string)$r);
		} else {
			update_option('kt680651_timemin', (string)$time6sec_a);
			update_option('kt680651_actionsinmin', '1');
			$r = 1;
		}
		return $r;
	}	
	
	add_action( 'admin_notices', 'kt680651_notice_balance_required' );
	function kt680651_notice_balance_required() {
		if (get_option('kt680651_balance_required', 'no') == 'yes') {
		?>
		<div class="notice notice-error">
			<p>Пополните баланс AI Rewriter API</p>
		</div>
		<?php
		}
	}
	
	function kt680651_translate_post($post_id) {
		global $kt680651_apikey;
		require_once(plugin_dir_path(__FILE__).'phpQuery.php');
		if (!empty($kt680651_apikey)) {
			$a = kt680651_action_in_min();
			if ($a > 50) {
				update_post_meta($post_id, 'kt680651_status_translate', 'queue');
				wp_schedule_single_event(((int)time('U') + 60), 'kt680651_translate_post_queue', array($post_id));
			} else {
				$d = array();
				$langs = pll_languages_list(array('fields' => 'locale'));
				$ls = array();
				foreach ($langs as $lang) {
					$l = mb_strtoupper(explode('_', $lang)[0]);
					if (!in_array($l, $ls) && $l != 'RU') {
						$ls[] = $l;
					}
				}
				$d['langs'] = $ls;
				
				$p = get_post($post_id);
				
				$content = $p->post_content;
        		$content = wpautop($content);
        		$content = str_replace(']]>', ']]&gt;', $content);
        		
        		$content = preg_replace('/\>\s+\</m', '><', $content);
		
        		$doc = phpQuery::newDocument($content);
		
        		$blocks = [];
        		$images_html = [];
		
        		$content = htmlspecialchars($content);
        		
        		$log = 'Blocks:'.chr(10);
        		$bnnn = 0;
        		kt680651_recursion($doc, $blocks, $content, $log, $bnnn);
        		$pst = preg_split('/<[^<>]*>/', htmlspecialchars_decode($content));
				foreach ($pst as $psl) {
					$psl = trim($psl);
					if (!empty($psl) && $psl != '{' && $psl != '{{' && $psl != '}' && $psl != '}}' && $psl != ' d_') {
						$pmm = array();
						preg_match('/{{[\s]*d_[0-9]*[\s]*}}/', $psl, $pmm);
						if (!isset($pmm[0])) {
							$old_html = $content;
                    			
                			$pos = strpos($content, htmlspecialchars($psl));
                			if ($pos !== false) {
                    			$content = substr_replace($content, '{{ d_'.$bnnn.' }}', $pos, strlen(htmlspecialchars($psl)));
                			}
                			
                			if ($old_html != $content) {
                 				$bnnn++;
                    			$log = $log.($bnnn - 1).': text: '.$psl.chr(10);
                    			$blocks[] = [
                        			'type' => 'paragraph',
                        			'data' => [
                            			'text' => $psl
                        			]
                    			];
                			}
						}
					}
				}	
				$log = $log.'--------------------------------'.chr(10);     		
        		$content = htmlspecialchars_decode($content);
        		
            	update_post_meta($post_id, 'kt680651_temp_content', $content);
				
				$postdata = array();
				$postdata[] = $p->post_title;
				$postdata[] = get_post_meta($post_id, '_yoast_wpseo_metadesc', 1);
				$postdata[] = get_post_meta($post_id, '_yoast_wpseo_title', 1);
				$postdata[] = get_post_meta($post_id, '_yoast_wpseo_focuskw', 1);
				$d['blocks'] = array();
				foreach ($postdata as $idx => $postinfo) {
					if (!empty(trim($postinfo))) {
						if ($idx == 0) {
							$d['blocks'][] = array('type' => 'header', 'data' => array('text' => $postinfo, 'level' => 2));
						} else {
							$d['blocks'][] = array('type' => 'paragraph', 'data' => array('text' => $postinfo));
						}
						if ($idx == 0) {
							$log = $log.'Title: '.$postinfo.chr(10);
						} elseif ($idx == 1) {
							$log = $log.'Yoast SEO Description: '.$postinfo.chr(10);
						} elseif ($idx == 2) {
							$log = $log.'Yoast SEO Title: '.$postinfo.chr(10);
						} elseif ($idx == 3) {
							$log = $log.'Yoast SEO Keyword: '.$postinfo.chr(10);
						}
					}
				}
				foreach ($blocks as $block) {
					$d['blocks'][] = $block;
				}
				kt680651_debug_log('Post '.$post_id.' sended to translate', trim($log));
				$pr = kt680651_sendAPIpost('https://api.dofiltra.com/api/translate/add', $d);
				$j = json_decode($pr, 1) or $j = null;
				if ($j !== null) {
					if ($j['error'] === null) {
						update_option('kt680651_balance_required', 'no');
						update_post_meta($post_id, 'kt680651_id_translate', $j['result']['_id']);
						update_post_meta($post_id, 'kt680651_status_translate', $j['result']['status']);
						if ($j['result']['status'] == 9) {
							kt680651_apply_translate_post($post_id, $j['result']['blocks']);
						}
					} else {
						if ($j['error'] == 'BALANCE_REQUIRED') {
							update_option('kt680651_balance_required', 'yes');
						} else {
							update_option('kt680651_balance_required', 'no');
						}
						update_post_meta($post_id, 'kt680651_status_translate', '');
					}
				} else {
					update_post_meta($post_id, 'kt680651_status_translate', '');
				}
			}
		}
	}
	
	add_action( 'kt680651_translate_post_queue', 'kt680651_translate_post', 10, 1 );
	
	function kt680651_apply_translate_post($post_id, $blocks) {
		require_once(plugin_dir_path(__FILE__).'phpQuery.php');
		$langs = pll_languages_list(array('fields' => 'locale'));
		$ls = array();
		foreach ($langs as $lang) {
			$l = mb_strtoupper(explode('_', $lang)[0]);
			if (!isset($ls[$l])) {
				$ls[$l] = $lang;
			}
		}
		
		$p = get_post($post_id);
		$postdata = array();
		$postdata[] = $p->post_title;
		$postdata[] = get_post_meta($post_id, '_yoast_wpseo_metadesc', 1);
		$postdata[] = get_post_meta($post_id, '_yoast_wpseo_title', 1);
		$postdata[] = get_post_meta($post_id, '_yoast_wpseo_focuskw', 1);
		$postdata[] = 'I';
		$d['blocks'] = array();
		$tps = null;
		$tf = pll_get_post_translations( $post_id );
		$fidx = 0;
		foreach ($postdata as $idx => $postinfo) {
			if (!empty(trim($postinfo))) {
				if ($idx == 0) {
					$tps = get_post($post_id, ARRAY_A);
					unset($tps['ID']);
					unset($tps['post_name']);
					unset($tps['guid']);
					unset($tps['comment_count']);
					unset($tps['tags_input']);
					foreach ($blocks[$fidx]['results'] as $rlang => $rldata) {
						$rl = mb_strtolower($rlang);
						if ($rl != 'ru') {
							$tps['post_title'] = $blocks[$fidx]['results'][$rlang]['text'];
							if (!isset($tf[$rl])) {
								$tf[$rl] = wp_insert_post($tps);
							} else {
								$tps['ID'] = $tf[$rl];
								wp_update_post($tps);
							}
							$taxonomies = get_object_taxonomies( get_post_type( $p ) );
							if( $taxonomies ) {
								foreach ( $taxonomies as $taxonomy ) {
									if ($taxonomy != 'term_language' && $taxonomy != 'language' && $taxonomy != 'term_translations' && $taxonomy != 'post_translations') {
										$post_terms = wp_get_object_terms( $post_id, $taxonomy, array( 'fields' => 'slugs' ) );
										wp_set_object_terms( $tf[$rl], $post_terms, $taxonomy, false );
									}
								}
							}
							$post_meta = get_post_meta( $post_id );
							if( $post_meta ) {
								foreach ( $post_meta as $meta_key => $meta_values ) {
									if( '_wp_old_slug' != $meta_key && '_yoast_wpseo_canonical' != $meta_key ) {
										foreach ( $meta_values as $meta_value ) {
											add_post_meta( $tf[$rl], $meta_key, $meta_value );
										}
									}									
								}
							}
							pll_set_post_language( $tf[$rl], $rl );					
						}
					}
					pll_save_post_translations($tf);
				} elseif ($tps !== null) {
					if ($idx == 1) {
						foreach ($blocks[$fidx]['results'] as $rlang => $rldata) {
							$rl = mb_strtolower($rlang);
							if ($rl != 'ru') {
								update_post_meta($tf[$rl], '_yoast_wpseo_metadesc', $blocks[$fidx]['results'][$rlang]['text']);
							}
						}
					} elseif ($idx == 2) {
						foreach ($blocks[$fidx]['results'] as $rlang => $rldata) {
							$rl = mb_strtolower($rlang);
							if ($rl != 'ru') {
								update_post_meta($tf[$rl], '_yoast_wpseo_title', str_replace('%%%%%', '%% %%', $blocks[$fidx]['results'][$rlang]['text']));
							}
						}
					} elseif ($idx == 3) {
						foreach ($blocks[$fidx]['results'] as $rlang => $rldata) {
							$rl = mb_strtolower($rlang);
							if ($rl != 'ru') {
								update_post_meta($tf[$rl], '_yoast_wpseo_focuskw', $blocks[$fidx]['results'][$rlang]['text']);
							}
						}
					} elseif ($idx == 4) {
						$ppi = $fidx;
						$pql = 0;
						$temp_content = get_post_meta($post_id, 'kt680651_temp_content', true);
						$temp_contents = array();
						
						while ($ppi < count($blocks)) {
							$block = $blocks[$ppi];
							$type = $block['type'];
							if (in_array($type, ['header', 'paragraph', 'list'])) {
                                if ($type == 'header') {
                                	foreach ($block['results'] as $rlang => $rldata) {
                                		$rl = mb_strtolower($rlang);
										if ($rl != 'ru') {
											if (!isset($temp_contents[$rl])) {
												$temp_contents[$rl] = $temp_content;
											}
											
                                    		$new_data = $block['results'][$rlang]['text'];
		
                                    		$temp_contents[$rl] = str_replace('{{ d_'.$pql.' }}', $new_data, $temp_contents[$rl]);
                                    
										}
                                	}

                                } else if ($type == 'paragraph') {
                                	foreach ($block['results'] as $rlang => $rldata) {
                                		$rl = mb_strtolower($rlang);
										if ($rl != 'ru') {
											if (!isset($temp_contents[$rl])) {
												$temp_contents[$rl] = $temp_content;
											}
											
                                    		$new_data = $block['results'][$rlang]['text'];
		
                                    		$temp_contents[$rl] = str_replace('{{ d_'.$pql.' }}', $new_data, $temp_contents[$rl]);
                                    
										}
                                	}
                                } else if ($type == 'list') {
                                	foreach ($block['results'] as $rlang => $rldata) {
                                		$rl = mb_strtolower($rlang);
										if ($rl != 'ru') {
											if (!isset($temp_contents[$rl])) {
												$temp_contents[$rl] = $temp_content;
											}
											
											$items = $block['results'][$rlang]['items'];
											
											$list_items_html = '';
											
											foreach ($items as $itm) {
                                        		$list_items_html .= '<li>'.$itm.'</li>';
                                    		}
		
                                        	$temp_contents[$rl] = str_replace('{{ d_'.$pql.' }}', $list_items_html, $temp_contents[$rl]);
                                    
										}
                                	}
                                }
                            }
                            $pql++;
							$ppi++;
						}
						foreach ($temp_contents as $rl => $rlcontent) {
							if ($rl != 'ru') {
								wp_update_post(array('ID' => $tf[$rl], 'post_content' => $rlcontent));
								delete_post_meta($tf[$rl], 'kt680651_temp_content');
							}
						}
						delete_post_meta($post_id, 'kt680651_temp_content');
					}
				}
				$fidx++;
			}
		}
	}
	
	
    
    add_action('kt680651_status_translate_posts_queue', 'kt680651_status_translate_posts');
	function kt680651_status_translate_posts() {
		$posts = get_posts(array(
			'numberposts' => -1,
			'category'    => 0,
			'orderby'     => 'date',
			'order'       => 'ASC',
			'post_status' => 'any',
			'meta_query'  => array(
				array('key' => 'kt680651_status_translate', 'compare' => 'EXISTS'),
				array('key' => 'kt680651_status_translate', 'value' => 'queue', 'compare' => '!='),
				array('key' => 'kt680651_status_translate', 'value' => '9', 'compare' => '!='),
			),
			'post_type'   => 'post',
			'suppress_filters' => true,
		));
		$ids = array();
		foreach ($posts as $p) {
			$tid = get_post_meta($p->ID, 'kt680651_id_translate', 1);
			if (!empty($tid)) {
				if (get_post_meta($p->ID, 'kt680651_status_translate', 1) != '') {
					$ids[] = $tid;
				}
			}			
			
		}			
		if (count($ids) > 0) {
			$pr = kt680651_sendAPIpost('https://api.dofiltra.com/api/translate/getStatuses', array('ids' => $ids));
			$j = json_decode($pr, 1) or $j = null;
			if ($j !== null) {
				foreach($j['result'] as $jr) {
					if ($jr['status'] == 9) {
						kt680651_translate_by_tid($jr['_id']);
					} else {
						$ff = get_posts(array(
							'numberposts' => 1,
							'category'    => 0,
							'orderby'     => 'date',
							'order'       => 'ASC',
							'meta_key'    => 'kt680651_id_translate',
							'meta_value'  => $jr['_id'],
							'post_type'   => 'post',
							'post_status' => 'any',
							'fields'      => 'ids',
							'suppress_filters' => true,
						));
						if (isset($ff[0])) {
							update_post_meta($ff[0], 'kt680651_status_translate', $jr['status']);
						}
					}
				}
			}
		}
	}
	
	function kt680651_translate_by_tid($tid) {
		global $kt680651_apikey;
		if (!empty($kt680651_apikey)) {
			$a = kt680651_action_in_min();
			if ($a > 50) {
				wp_schedule_single_event(((int)time('U') + 60), 'kt680651_translate_by_tid_queue', array($tid));
			} else {
				$ff = get_posts(array(
					'numberposts' => 1,
					'category'    => 0,
					'orderby'     => 'date',
					'order'       => 'ASC',
					'meta_key'    => 'kt680651_id_translate',
					'meta_value'  => $tid,
					'post_type'   => 'post',
					'post_status' => 'any',
					'fields'      => 'ids',
					'suppress_filters' => true,
				));
				if (isset($ff[0])) {
					$pr = kt680651_sendAPIget('https://api.dofiltra.com/api/translate/get?id='.urlencode($tid));
					$j = json_decode($pr, 1) or $j = null;
					if ($j !== null) {
						update_post_meta($ff[0], 'kt680651_status_translate', 9);
						kt680651_apply_translate_post($ff[0], $j['item']['blocks']);
					}
				}
			}
		}
	}
		
	add_action( 'kt680651_translate_by_tid_queue', 'kt680651_translate_by_tid', 10, 1 );
	
	register_activation_hook(__FILE__, 'kt680651_activation');
	function kt680651_activation() {
		wp_clear_scheduled_hook( 'kt680651_status_translate_posts_queue' );
		wp_schedule_event( time(), 'kt680651_check_status_period', 'kt680651_status_translate_posts_queue');
	}
	
	register_deactivation_hook( __FILE__, 'kt680651_deactivation');
	function kt680651_deactivation() {
		wp_clear_scheduled_hook('kt680651_status_translate_posts_queue');
	}
	
	add_filter( 'cron_schedules', 'kt680651_cron_add_check_status_period' );
	function kt680651_cron_add_check_status_period( $schedules ) {
		$schedules['kt680651_check_status_period'] = array(
			'interval' => 120,
			'display' => 'kt680651_check_status_period'
		);
		return $schedules;
	}
	if( ! wp_next_scheduled( 'kt680651_status_translate_posts_queue' ) ) { 
		wp_schedule_event( time(), 'kt680651_check_status_period', 'kt680651_status_translate_posts_queue');
	}

	function kt680651_translate_post_jquery( $capability ) {
        ?>
        <script>
            function kt680651_translate_post(post_id, el) {
                if (el.textContent != 'Подождите...') {
                    jQuery(document).ready( function( $ ){
                        var data = {
                            action: 'kt680651_translate_post',
                            postid: post_id
                        };

                        jQuery.ajax({
                            url: ajaxurl,
                            method: 'post',
                            dataType: 'html',
                            data: data,
                            success: function () {
                                window.location.href = window.location.href;
                            },
                            error: function () {
                                el.textContent = 'Перевести';
                                alert('Ошибка');
                            }
                        });
                        el.textContent = 'Подождите...';
                    } );
                }
            }
        </script><?php
	}
	
	add_action( 'admin_footer', 'kt680651_translate_post_jquery' );

	function kt680651_translate_post_ajax() {
		if (isset($_POST['postid'])) {
			$post_id = (int)$_POST['postid'];
        	if (current_user_can('edit_post', $post_id)) {
        		$s = get_post_meta($post_id, 'kt680651_status_translate', 1);
        		if (empty($s) || $s == '9') {
        			if (pll_get_post_language( $post_id, 'slug' ) == 'ru') {
        				kt680651_translate_post($post_id);
        				return true;
        			}
        		}
        	}
        }
        return false;
	}
	
	add_action( 'wp_ajax_kt680651_translate_post', 'kt680651_translate_post_ajax' );
	
	function kt680651_recursion($doc, &$blocks, &$html, &$log, &$bnnn) {
        foreach (pq($doc)->find('*') as $el) {
        	if ($el->tagName == 'tr') {
        		$log = $log.'TABLE LINE'.chr(10);
        	}
        	if ($el->tagName == 'table') {
        		$log = $log.'TABLE'.chr(10);
        	}
            if (pq($el)->text() == '') {
                kt680651_recursion($el, $blocks, $content, $log, $bnnn);
            } else {
                if (in_array($el->tagName, ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'])) {
                    $to_replace = (string)(pq($el));
                    $to_replace = preg_replace('/\>\s+\</m', '><', $to_replace);
                    $to_replace = htmlspecialchars($to_replace);

                    $old_html = $html;
                    
                    $pos = strpos($html, $to_replace);
                    if ($pos !== false) {
                        $html = substr_replace($html, '<h' . str_replace('h', '', $el->tagName) . '>{{ d_'.$bnnn.' }}</h' . str_replace('h', '', $el->tagName) . '>', $pos, strlen($to_replace));
                    }
                    
                    if ($old_html != $html) {
                    	$bnnn++;
                    	$log = $log.($bnnn - 1).': '.mb_strtoupper($el->tagName).': '.pq($el)->text().chr(10);
                        $blocks[] = [
                            'type' => 'header',
                            'data' => [
                                'text' => pq($el)->text(),
                                'level' => str_replace('h', '', $el->tagName)
                            ]
                        ];
                    }
                } else if (in_array($el->tagName, ['p', 'b', 'strong', 'i', 'em', 'u', 's', 'del', 'span', 'div'])) {
                    $to_replace = (string)(pq($el));
                    $to_replace = preg_replace('/\>\s+\</m', '><', $to_replace);
                    $to_replace = htmlspecialchars($to_replace);

                    $old_html = $html;
                    
                    $pos = strpos($html, $to_replace);
                    if ($pos !== false) {
                    	$eatt = $el->attributes;
                    	if ($eatt === null) {
                    		$atts = '';
                    	} else {
                    		$atts = ' ';
                    		foreach ($eatt as $att) {
                    			$atts = $atts.' '.$att->name.'="'.$att->value.'"';
                    		}
                    	}
                        $html = substr_replace($html, '<'.$el->tagName.$atts.'>{{ d_'.$bnnn.' }}</'.$el->tagName.'>', $pos, strlen($to_replace));
                    }
                    
                    if ($old_html != $html) {
                    	$bnnn++;
                    	$log = $log.($bnnn - 1).': '.mb_strtoupper($el->tagName).': '.pq($el)->text().chr(10);
                        $blocks[] = [
                            'type' => 'paragraph',
                            'data' => [
                                'text' => pq($el)->text()
                            ]
                        ];
                    }
                } else if ($el->tagName == 'td') {
                    $to_replace = (string)(pq($el));
                    $to_replace = preg_replace('/\>\s+\</m', '><', $to_replace);
                    $to_replace = htmlspecialchars($to_replace);

                    $old_html = $html;
                    
                    $pos = strpos($html, $to_replace);
                    if ($pos !== false) {
                        $html = substr_replace($html, '<td>{{ d_'.$bnnn.' }}</td>', $pos, strlen($to_replace));
                    }
                    
                    if ($old_html != $html) {
                 		$bnnn++;
                    	$log = $log.($bnnn - 1).': '.mb_strtoupper($el->tagName).': '.pq($el)->text().chr(10);
                        $blocks[] = [
                            'type' => 'paragraph',
                            'data' => [
                                'text' => pq($el)->text()
                            ]
                        ];
                    }
                } else if ($el->tagName == 'th') {
                    $to_replace = (string)(pq($el));
                    $to_replace = preg_replace('/\>\s+\</m', '><', $to_replace);
                    $to_replace = htmlspecialchars($to_replace);

                    $old_html = $html;
                    
                    $pos = strpos($html, $to_replace);
                    if ($pos !== false) {
                        $html = substr_replace($html, '<th>{{ d_'.$bnnn.' }}</th>', $pos, strlen($to_replace));
                    }
                    
                    if ($old_html != $html) {
                 		$bnnn++;
                    	$log = $log.($bnnn - 1).': '.mb_strtoupper($el->tagName).': '.pq($el)->text().chr(10);
                        $blocks[] = [
                            'type' => 'paragraph',
                            'data' => [
                                'text' => pq($el)->text()
                            ]
                        ];
                    }
                } else if (in_array($el->tagName, ['ul', 'ol'])) {
                    $style = 'ordered';
                    if ($el->tagName == 'ul') {
                        $style = 'unordered';
                    }
        
                    $lis = pq($el)->find('li');
                    $items = [];
        
                    foreach ($lis as $li) {
                        $items[] = pq($li)->text();
                    }
                    
                    $to_replace = (string)(pq($el));
                    $to_replace = preg_replace('/\>\s+\</m', '><', $to_replace);
                    $to_replace = htmlspecialchars($to_replace);
                    
                    $old_html = $html;
                    
                    if ($style == 'ordered') {
                        $pos = strpos($html, $to_replace);
                        if ($pos !== false) {
                            $html = substr_replace($html, '<ol>{{ d_'.$bnnn.' }}</ol>', $pos, strlen($to_replace));
                        }
                    } else {
                        $pos = strpos($html, $to_replace);
                        if ($pos !== false) {
                            $html = substr_replace($html, '<ul>{{ d_'.$bnnn.' }}</ul>', $pos, strlen($to_replace));
                        }
                    }
        
                    if ($old_html != $html) {
                 		$bnnn++;
                    	$log = $log.($bnnn - 1).': '.mb_strtoupper($el->tagName).': '.implode('; ', $items).chr(10);
                        $blocks[] = [
                            'type' => 'list',
                            'data' => [
                                'style' => $style,
                                'items'=> $items
                            ]
                        ];
                    }
                } else {
                	$ttt1 = (string)(pq($el));
                	$ttt2 = explode('>', $ttt1)[0];
                	$ttt3 = str_replace("'", '"', $ttt2);
                	$alt1 = explode('alt="', $ttt3);
                	if (strpos(' title=', $alt1[0]) !== false) {
                		$title1 = explode('title="', $ttt3);
                		if (isset($title1[1])) {
                			$title0 = '"'.explode('"', $alt[1])[0].'"';
                			$pos = strpos($html, $title0);
                			$old_html = $html;
                    		if ($pos !== false) {
                        		$html = substr_replace($html, '{{ d_'.$bnnn.' }}', $pos, strlen($title0));
                    		}
                    		if ($old_html != $html) {
                 				$bnnn++;
                    			$log = $log.($bnnn - 1).': '.mb_strtoupper($el->tagName).': '.pq($el)->text().chr(10);
                        		$blocks[] = [
                            		'type' => 'paragraph',
                            		'data' => [
                                		'text'=> $title0
                            		]
                        		];
                    		}
                    	}
                		if (isset($alt1[1])) {
                			$alt = '"'.explode('"', $alt[1])[0].'"'; //"
                			$pos = strpos($html, $alt);
                			$old_html = $html;
                    		if ($pos !== false) {
                        		$html = substr_replace($html, '{{ d_'.$bnnn.' }}', $pos, strlen($alt));
                    		}
                    		if ($old_html != $html) {
                 				$bnnn++;
                    			$log = $log.($bnnn - 1).': '.mb_strtoupper($el->tagName).': '.pq($el)->text().chr(10);
                        		$blocks[] = [
                            		'type' => 'paragraph',
                            		'data' => [
                                		'text'=> $alt
                            		]
                        		];
                    		}
                    	}
                	} else {
                		if (isset($alt1[1])) {
                			$alt = '"'.explode('"', $alt[1])[0].'"'; //"
                			$pos = strpos($html, $alt);
                			$old_html = $html;
                    		if ($pos !== false) {
                        		$html = substr_replace($html, '{{ d_'.$bnnn.' }}', $pos, strlen($alt));
                    		}
                    		if ($old_html != $html) {
                 				$bnnn++;
                    			$log = $log.($bnnn - 1).': '.mb_strtoupper($el->tagName).': '.pq($el)->text().chr(10);
                        		$blocks[] = [
                            		'type' => 'paragraph',
                            		'data' => [
                                		'text'=> $alt
                            		]
                        		];
                    		}
                    	}
                		$title1 = explode('title="', $ttt3);
                		if (isset($title1[1])) {
                			$title0 = '"'.explode('"', $alt[1])[0].'"';
                			$pos = strpos($html, $title0);
                			$old_html = $html;
                    		if ($pos !== false) {
                        		$html = substr_replace($html, '{{ d_'.$bnnn.' }}', $pos, strlen($title0));
                    		}
                    		if ($old_html != $html) {
                 				$bnnn++;
                    			$log = $log.($bnnn - 1).': '.mb_strtoupper($el->tagName).': '.pq($el)->text().chr(10);
                        		$blocks[] = [
                            		'type' => 'paragraph',
                            		'data' => [
                                		'text'=> $title0
                            		]
                        		];
                    		}
                    	}
                    }
                }
            }
        }

	}

}
